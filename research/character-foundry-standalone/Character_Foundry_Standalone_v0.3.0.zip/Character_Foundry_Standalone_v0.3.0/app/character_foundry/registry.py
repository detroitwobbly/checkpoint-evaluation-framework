from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any

from .io import read_json, sha256_file

SHA256 = re.compile(r"^[0-9a-f]{64}$")
ROLES = {"canonical_identity", "presentation"}


def load_registry(path: Path) -> dict[str, Any]:
    registry = read_json(path)
    validate_registry(registry)
    return registry


def validate_registry(registry: Any) -> None:
    if not isinstance(registry, dict):
        raise ValueError("SliderRegistry must be an object")
    version = registry.get("schema_version")
    if version not in {"character-factory.slider-registry.v0.1", "character-factory.slider-registry.v0.2", "character-factory.slider-registry.v0.3"}:
        raise ValueError(f"Unsupported SliderRegistry schema_version {version!r}; migrate to v0.3")
    seen: set[str] = set()
    for entry in registry.get("sliders", []):
        slider_id = str(entry.get("slider_id", ""))
        if not slider_id or slider_id in seen:
            raise ValueError(f"Missing or duplicate slider_id: {slider_id!r}")
        seen.add(slider_id)
        if entry.get("role") not in ROLES:
            raise ValueError(f"Invalid slider role for {slider_id}")
        allowed_roles = set(entry.get("allowed_roles", [entry.get("role")]))
        if not allowed_roles or not allowed_roles <= ROLES or entry.get("role") not in allowed_roles:
            raise ValueError(f"Invalid allowed_roles for {slider_id}")
        digest = str(entry.get("sha256", ""))
        if not SHA256.fullmatch(digest):
            raise ValueError(f"Invalid SHA-256 for {slider_id}")
        low, high = entry.get("validated_range", [None, None])
        if entry.get("selectable", False):
            if not all(isinstance(value, (int, float)) for value in (low, high, entry.get("step_size"), entry.get("default_weight"))):
                raise ValueError(f"Selectable slider {slider_id} requires numeric range, step, and default")
            if low > high or not low <= entry["default_weight"] <= high or entry["step_size"] <= 0:
                raise ValueError(f"Invalid validated range for {slider_id}")


def resolve_stack(
    manifest: dict[str, Any],
    registry: dict[str, Any],
    *,
    presentation: list[dict[str, Any]] | None = None,
    verify_assets: bool = False,
) -> list[dict[str, Any]]:
    validate_registry(registry)
    by_id = {item["slider_id"]: item for item in registry["sliders"]}
    canonical = manifest.get("canonical_appearance", {}).get("sliders", [])
    presentation = presentation or []
    selected = [*(dict(item, selected_as="canonical_identity") for item in canonical), *(dict(item, selected_as="presentation") for item in presentation)]
    resolved: list[dict[str, Any]] = []
    selected_ids: set[str] = set()
    for order, choice in enumerate(selected):
        if not choice.get("enabled", True):
            continue
        slider_id = choice.get("slider_id")
        if slider_id not in by_id:
            raise ValueError(f"Unknown slider_id: {slider_id}")
        if slider_id in selected_ids:
            raise ValueError(f"Duplicate slider selection: {slider_id}")
        selected_ids.add(slider_id)
        definition = by_id[slider_id]
        if not str(definition.get("positive_pole", "")).strip() or not str(definition.get("negative_pole", "")).strip():
            raise ValueError(f"Slider {slider_id} requires explicit positive and negative pole meanings")
        if not definition.get("selectable", False):
            raise ValueError(f"Slider is discovered but not validated for use: {slider_id}")
        weight = choice.get("weight")
        low, high = definition["validated_range"]
        if not isinstance(weight, (int, float)) or not low <= weight <= high:
            raise ValueError(f"Weight {weight!r} is outside validated range for {slider_id}: {low}..{high}")
        allowed_roles = definition.get("allowed_roles", [definition["role"]])
        if choice["selected_as"] not in allowed_roles:
            raise ValueError(
                f"Slider {slider_id} allows roles {allowed_roles!r} and cannot be selected as {choice['selected_as']!r}"
            )
        step = float(definition["step_size"])
        steps = (float(weight) - float(low)) / step
        if not math.isclose(steps, round(steps), abs_tol=1e-8):
            raise ValueError(f"Weight {weight!r} is not aligned to step {step} from {low} for {slider_id}")
        asset = Path(str(definition["file_path"]))
        if verify_assets:
            if not asset.is_file():
                raise FileNotFoundError(f"Slider asset is missing for {slider_id}: {asset}")
            actual_hash = sha256_file(asset)
            if actual_hash != definition["sha256"]:
                raise ValueError(f"Slider asset SHA-256 mismatch for {slider_id}: expected {definition['sha256']}, got {actual_hash}")
            checkpoint_hash = str(manifest.get("canonical_appearance", {}).get("checkpoint", {}).get("sha256", ""))
            compatible = definition.get("compatible_checkpoint_sha256", [])
            if compatible and checkpoint_hash not in compatible:
                raise ValueError(f"Slider {slider_id} is not registered as compatible with checkpoint {checkpoint_hash}")
        resolved.append(
            {
                "stack_order": order,
                "slider_id": slider_id,
                "display_name": definition["display_name"],
                "file_path": definition["file_path"],
                "sha256": definition["sha256"],
                "weight": weight,
                "role": choice["selected_as"],
                "positive_pole": definition["positive_pole"],
                "negative_pole": definition["negative_pole"],
                "validated_range": list(definition["validated_range"]),
                "step_size": definition["step_size"],
                "compatible_checkpoint_sha256": list(definition.get("compatible_checkpoint_sha256", [])),
            }
        )
    return resolved


def discover_slider_files(root: Path, *, hash_files: bool = False) -> dict[str, Any]:
    root = root.resolve()
    files = []
    for path in sorted(root.rglob("*.safetensors"), key=lambda item: str(item).casefold()):
        stat = path.stat()
        files.append(
            {
                "filename": path.name,
                "relative_path": path.relative_to(root).as_posix(),
                "absolute_path": str(path),
                "size_bytes": stat.st_size,
                "sha256": sha256_file(path) if hash_files else None,
                "status": "discovered_unvalidated",
            }
        )
    return {
        "schema_version": "character-factory.slider-discovery.v0.1",
        "root": str(root),
        "files": files,
        "notice": "Discovery does not establish polarity, range, compatibility, or safety.",
    }


def freeze_appearance(manifest: dict[str, Any], registry: dict[str, Any] | None = None, *, verify_assets: bool = False) -> dict[str, Any]:
    from .io import stable_digest

    appearance = manifest.setdefault("canonical_appearance", {})
    checkpoint_hash = str(appearance.get("checkpoint", {}).get("sha256", ""))
    if not SHA256.fullmatch(checkpoint_hash):
        raise ValueError("Canonical appearance requires the checkpoint's full lowercase SHA-256 before it can be frozen")
    prior = appearance.get("revision", 0)
    appearance["revision"] = int(prior) + 1
    appearance["frozen"] = True
    appearance["fingerprint"] = stable_digest({key: value for key, value in appearance.items() if key != "fingerprint"})
    if registry is not None:
        resolve_stack(manifest, registry, verify_assets=verify_assets)
    return manifest

