from __future__ import annotations

from pathlib import Path
from typing import Any

from .foundry import BODY_BUILD_OPTIONS, BODY_SHAPE_OPTIONS, OPTIONS
from .io import read_json, stable_digest


DESCRIPTOR_SCHEMAS = {
    "character-foundry.descriptor-catalog.v0.1",
    "character-foundry.descriptor-catalog.v0.2",
    "character-foundry.descriptor-catalog.v0.3",
}


def load_descriptor_catalog(path: Path) -> dict[str, Any]:
    value = read_json(path)
    if not isinstance(value, dict) or value.get("schema_version") not in DESCRIPTOR_SCHEMAS:
        raise ValueError(f"Unsupported descriptor catalog schema in {path}")
    attributes = value.get("attributes")
    clothing = value.get("clothing_categories")
    if not isinstance(attributes, dict):
        raise ValueError("Descriptor catalog attributes must be an object")
    schema = str(value.get("schema_version", ""))
    if schema.endswith(("v0.1", "v0.2")):
        legacy_keys = set(OPTIONS).difference({"body_shape"})
        if set(attributes) != legacy_keys:
            raise ValueError(f"Legacy descriptor catalog attributes must be exactly: {sorted(legacy_keys)}")
        attributes = dict(attributes)
        attributes["body_build"] = list(BODY_BUILD_OPTIONS)
        attributes["body_shape"] = list(BODY_SHAPE_OPTIONS)
    elif set(attributes) != set(OPTIONS):
        raise ValueError(f"Descriptor catalog attributes must be exactly: {sorted(OPTIONS)}")
    for key, entries in attributes.items():
        if not isinstance(entries, list) or not entries:
            raise ValueError(f"Descriptor section {key!r} must be a non-empty list")
        if any(not isinstance(item, str) or not item.strip() for item in entries):
            raise ValueError(f"Descriptor section {key!r} contains an empty or non-text value")
        if len(entries) != len(set(entries)):
            raise ValueError(f"Descriptor section {key!r} contains duplicates")
    if not isinstance(clothing, dict) or not clothing:
        raise ValueError("Descriptor catalog clothing_categories must be a non-empty object")
    if any(not isinstance(key, str) or not key.strip() or not isinstance(text, str) or not text.strip()
           for key, text in clothing.items()):
        raise ValueError("Clothing category names and prompts must be non-empty text")
    ancestry = value.get("ancestry_background")
    if schema.endswith(("v0.2", "v0.3")):
        _validate_ancestry_catalog(ancestry)
    result = dict(value)
    result["attributes"] = attributes
    if ancestry is None:
        result["ancestry_background"] = {
            "sampling": {"random_enabled": False},
            "groups": [],
            "mixed": {"enabled": False, "random_enabled": False, "min_entries": 2, "max_entries": 4},
            "custom": {"enabled": True},
            "unspecified": {"enabled": True, "label": "Unspecified"},
        }
    result["fingerprint"] = stable_digest({key: item for key, item in value.items() if key != "fingerprint"})
    return result


def _validate_ancestry_catalog(value: Any) -> None:
    if not isinstance(value, dict):
        raise ValueError("Descriptor catalog ancestry_background must be an object")
    groups = value.get("groups")
    if not isinstance(groups, list) or not groups:
        raise ValueError("Ancestry catalog groups must be a non-empty list")
    group_ids: set[str] = set()
    entry_ids: set[str] = set()
    entry_labels: set[str] = set()
    for group in groups:
        if not isinstance(group, dict):
            raise ValueError("Every ancestry group must be an object")
        group_id = str(group.get("id", "")).strip()
        label = str(group.get("label", "")).strip()
        if not group_id or not label or group_id in group_ids:
            raise ValueError("Ancestry group IDs and labels must be non-empty and group IDs unique")
        group_ids.add(group_id)
        entries = group.get("entries")
        if not isinstance(entries, list) or not entries:
            raise ValueError(f"Ancestry group {group_id!r} must contain entries")
        for entry in entries:
            if not isinstance(entry, dict):
                raise ValueError(f"Ancestry entries in {group_id!r} must be objects")
            entry_id = str(entry.get("id", "")).strip()
            entry_label = str(entry.get("label", "")).strip()
            prompt_phrase = str(entry.get("prompt_phrase", "")).strip()
            if not entry_id or not entry_label or not prompt_phrase:
                raise ValueError(f"Ancestry entries in {group_id!r} need id, label, and prompt_phrase")
            folded_label = entry_label.casefold()
            if entry_id in entry_ids or folded_label in entry_labels:
                raise ValueError(f"Duplicate ancestry entry: {entry_id or entry_label}")
            entry_ids.add(entry_id)
            entry_labels.add(folded_label)
    mixed = value.get("mixed", {})
    if not isinstance(mixed, dict):
        raise ValueError("Ancestry mixed configuration must be an object")
    minimum = int(mixed.get("min_entries", 2))
    maximum = int(mixed.get("max_entries", 4))
    if minimum < 2 or maximum < minimum:
        raise ValueError("Mixed ancestry entry limits are invalid")
