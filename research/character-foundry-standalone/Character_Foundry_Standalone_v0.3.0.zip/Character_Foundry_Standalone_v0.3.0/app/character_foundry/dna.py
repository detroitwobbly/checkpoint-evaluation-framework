from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from .io import read_json, stable_digest

DNA_SCHEMA = "character-factory.character-dna.v0.1"
IMPORT_SCHEMA = "character-factory.dna-import-report.v0.1"
COMPILER_VERSION = "character-factory.prompt-compiler.v0.1"
PROVENANCE = {"user_declared", "imported_unverified", "generated_intent", "image_observed", "human_verified"}
MAX_IMPORT_BYTES = 1_000_000


class DNAValidationError(ValueError):
    pass


def attribute(value: Any, provenance: str, *, evidence_refs: list[str] | None = None) -> dict[str, Any]:
    if provenance not in PROVENANCE:
        raise DNAValidationError(f"Unsupported provenance classification: {provenance}")
    return {"value": value, "provenance": provenance, "evidence_refs": list(evidence_refs or [])}


def validate_dna(dna: dict[str, Any]) -> None:
    if not isinstance(dna, dict) or dna.get("schema_version") != DNA_SCHEMA:
        raise DNAValidationError(f"Unsupported Character DNA schema_version: {getattr(dna, 'get', lambda *_: None)('schema_version')!r}")
    if not str(dna.get("character_id", "")).strip():
        raise DNAValidationError("Character DNA requires character_id")
    for section in ("identity_invariants", "permitted_variations", "presentation_defaults"):
        if not isinstance(dna.get(section), dict):
            raise DNAValidationError(f"Character DNA requires object section {section}")
    for path, item in _walk_attributes(dna):
        provenance = item.get("provenance")
        if provenance not in PROVENANCE:
            raise DNAValidationError(f"Invalid provenance at {path}: {provenance!r}")
        if "value" not in item or not isinstance(item.get("evidence_refs", []), list):
            raise DNAValidationError(f"Malformed DNA attribute at {path}")
    expected = stable_digest({key: value for key, value in dna.items() if key != "fingerprint"})
    if dna.get("fingerprint") not in {None, expected}:
        raise DNAValidationError("Character DNA fingerprint is invalid")


def finalize_dna(dna: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(dna)
    result.pop("fingerprint", None)
    validate_dna(result)
    result["fingerprint"] = stable_digest(result)
    return result


def dna_from_character(
    character: dict[str, Any],
    *,
    presentation_defaults: dict[str, Any] | None = None,
    permitted_variations: dict[str, Any] | None = None,
    reference_anchors: list[dict[str, Any]] | None = None,
    failure_modes: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    identity = character["identity"]
    traits = [attribute(item, "user_declared") for item in identity.get("permanent_traits", [])]
    invariants = {
        "class_noun": attribute(identity["class_noun"], "user_declared"),
        "trigger": attribute(identity["trigger"], "user_declared"),
        "permanent_traits": attribute([item["value"] for item in traits], "user_declared"),
        "body_build": attribute(character.get("body_description", ""), "user_declared"),
    }
    dna = {
        "schema_version": DNA_SCHEMA,
        "dna_revision": int(character.get("character_dna", {}).get("dna_revision", 0)) + 1,
        "character_id": character["character_id"],
        "identity_invariants": invariants,
        "permitted_variations": deepcopy(permitted_variations or {}),
        "presentation_defaults": deepcopy(presentation_defaults or {}),
        "appearance_revision_reference": {
            "revision": character["canonical_appearance"]["revision"],
            "fingerprint": character["canonical_appearance"].get("fingerprint"),
        },
        "reference_anchors": deepcopy(reference_anchors if reference_anchors is not None else _references_from_character(character)),
        "failure_modes": deepcopy(failure_modes or []),
    }
    return finalize_dna(dna)


def export_dna(character: dict[str, Any], dna: dict[str, Any], *, mode: str) -> dict[str, Any]:
    if mode not in {"portable", "factory"}:
        raise ValueError("DNA export mode must be portable or factory")
    validate_dna(dna)
    if mode == "factory":
        payload = {
            "schema_version": "character-factory.factory-dna-export.v0.1",
            "mode": mode,
            "character_id": character["character_id"],
            "dna": deepcopy(dna),
            "canonical_appearance": _sanitize_appearance(character["canonical_appearance"], portable=False),
            "authority_notice": "This export is evidence-bearing data, not an approval token. Reimport cannot grant approval.",
        }
    else:
        payload = {
            "schema_version": "character-factory.portable-dna-export.v0.1",
            "mode": mode,
            "character_id": character["character_id"],
            "identity_invariants": deepcopy(dna["identity_invariants"]),
            "permitted_variations": deepcopy(dna["permitted_variations"]),
            "presentation_defaults": deepcopy(dna["presentation_defaults"]),
            "reference_anchors": [_portable_anchor(item) for item in dna.get("reference_anchors", [])],
            "failure_modes": deepcopy(dna.get("failure_modes", [])),
            "appearance_snapshot": _sanitize_appearance(character["canonical_appearance"], portable=True),
        }
    payload["export_fingerprint"] = stable_digest(payload)
    return payload


def import_external_dna(path: Path, *, existing_dna: dict[str, Any] | None = None) -> dict[str, Any]:
    if path.stat().st_size > MAX_IMPORT_BYTES:
        raise DNAValidationError(f"DNA import exceeds {MAX_IMPORT_BYTES} bytes")
    source = read_json(path)
    if not isinstance(source, dict):
        raise DNAValidationError("DNA import root must be a JSON object")
    if "Character_DNA" not in source or not isinstance(source["Character_DNA"], dict):
        raise DNAValidationError("Unsupported external DNA: expected Character_DNA object")
    external = source["Character_DNA"]
    version = str(external.get("Version", ""))
    if version not in {"3.0"}:
        raise DNAValidationError(f"Unsupported external Character_DNA Version {version!r}")
    core = external.get("Core_Identity", {})
    body = external.get("Body_Proportions", {})
    hair = external.get("Hair_DNA", {})
    mapped: dict[str, Any] = {
        "character_label": attribute(external.get("Character_Label", ""), "imported_unverified"),
        "adult_age": attribute(core.get("Apparent_Age", ""), "imported_unverified"),
        "facial_geometry": attribute(core.get("Face_Shape", ""), "imported_unverified"),
        "eyes": attribute("; ".join(filter(None, [core.get("Iris_Color"), core.get("Eye_Shape_Spacing")])), "imported_unverified"),
        "skin": attribute("; ".join(filter(None, [core.get("Ethnicity_Skin_Tone"), core.get("Freckles_Skin_Texture")])), "imported_unverified"),
        "facial_features": attribute(core.get("Nose_Lips_Smile", ""), "imported_unverified"),
        "body_build": attribute("; ".join(str(value) for key, value in body.items() if key != "Intimate_Details"), "imported_unverified"),
        "natural_hair": attribute("; ".join(filter(None, [hair.get("Natural_Color"), hair.get("Texture"), hair.get("Length")])), "imported_unverified"),
    }
    presentation = {
        "expressions": attribute(external.get("Expression_Behavior", {}).get("Default_Expressions", []), "imported_unverified"),
        "hair_styles": attribute(hair.get("Versatile_Styles", []), "imported_unverified"),
        "wardrobe": attribute(external.get("Style_Identity", {}).get("Wardrobe_Core", []), "imported_unverified"),
        "settings": attribute(external.get("Scene_Guidance", {}).get("Best_Settings", []), "imported_unverified"),
        "rendering_guidance": attribute(external.get("Prompt_Bases", {}).get("Core_Invariant_String", ""), "imported_unverified"),
    }
    warnings = []
    if hair.get("Natural_Color") and any(word in str(hair["Natural_Color"]).lower() for word in ("long", "short", "ponytail", "wavy")):
        warnings.append({"path": "Character_DNA.Hair_DNA.Natural_Color", "issue": "Field mixes natural colour with length or styling; preserved for review."})
    age = str(core.get("Apparent_Age", "")).strip()
    if age and age.isdigit() and int(age) < 18:
        raise DNAValidationError("External character profile is not explicitly adult")
    if age == "18":
        warnings.append({"path": "Character_DNA.Core_Identity.Apparent_Age", "issue": "Boundary adult age requires explicit operator confirmation before use."})
    conflicts = []
    if existing_dna:
        current_age = existing_dna.get("identity_invariants", {}).get("adult_age", {}).get("value")
        if current_age not in {None, "", age}:
            conflicts.append({"path": "identity_invariants.adult_age", "existing": current_age, "imported": age})
    report = {
        "schema_version": IMPORT_SCHEMA,
        "source_path": str(path),
        "source_version": version,
        "source_fingerprint": stable_digest(source),
        "mapped_identity": mapped,
        "mapped_presentation": presentation,
        "warnings": warnings,
        "conflicts": conflicts,
        "unmapped_source": {key: deepcopy(value) for key, value in external.items() if key not in {"Core_Identity", "Body_Proportions", "Hair_DNA", "Expression_Behavior", "Style_Identity", "Scene_Guidance", "Prompt_Bases"}},
        "approval_state": "pending_explicit_approval",
        "notice": "Imported descriptions are unverified data and do not authorize generation, approval, or identity changes.",
    }
    report["report_fingerprint"] = stable_digest(report)
    return report


def approve_imported_identity(
    root: Path,
    report: dict[str, Any],
    *,
    approved_keys: list[str],
    registry: dict[str, Any],
) -> dict[str, Any]:
    """Reject the Factory-only approval transaction at the standalone boundary.

    Standalone Foundry can parse external DNA into a pending review report, but
    only Character Factory owns project journals and identity revisions.  Keep
    the public name for an intelligible compatibility error without importing
    the deliberately excluded ``character_factory.project`` dependency graph.
    """
    del root, report, approved_keys, registry
    raise DNAValidationError(
        "Imported-DNA approval is available only in Character Factory; "
        "standalone Character Foundry can inspect and preserve pending reports but cannot promote them."
    )


def compile_prompt(dna: dict[str, Any], presentation: dict[str, Any], *, backend: str) -> dict[str, Any]:
    validate_dna(dna)
    profiles = {
        "sdxl": {"separator": ", ", "prefix": ""},
        "juggernaut": {"separator": ", ", "prefix": ""},
        "destinyxl": {"separator": ", ", "prefix": ""},
        "generic": {"separator": ". ", "prefix": ""},
        "flux": {"separator": ". ", "prefix": "A coherent image of "},
    }
    if backend not in profiles:
        raise ValueError(f"Unsupported prompt backend profile: {backend}")
    identity_segments: list[str] = []
    for _, item in sorted(dna["identity_invariants"].items()):
        identity_segments.extend(_string_segments(item.get("value")))
    identity_segments = _deduplicate_segments(identity_segments)
    diagnostics = []
    protected = set(dna["identity_invariants"])
    conflicts = sorted(protected.intersection(presentation))
    if conflicts:
        diagnostics.append({"severity": "error", "message": f"Presentation attempts to override identity fields: {conflicts}"})
    presentation_segments: list[str] = []
    for key, value in sorted(presentation.items()):
        if key not in protected:
            presentation_segments.extend(_string_segments(value))
    presentation_segments = _deduplicate_segments(presentation_segments)
    segments = {"identity": identity_segments, "presentation": presentation_segments}
    profile = profiles[backend]
    text = profile["prefix"] + profile["separator"].join([*identity_segments, *presentation_segments])
    result = {
        "compiler_version": COMPILER_VERSION,
        "backend_profile": backend,
        "dna_fingerprint": dna["fingerprint"],
        "presentation_fingerprint": stable_digest(presentation),
        "segments": segments,
        "prompt": text,
        "diagnostics": diagnostics,
    }
    result["compile_fingerprint"] = stable_digest(result)
    return result


def _walk_attributes(value: Any, path: str = ""):
    if isinstance(value, dict):
        if "value" in value and "provenance" in value:
            yield path, value
        else:
            for key, child in value.items():
                yield from _walk_attributes(child, f"{path}.{key}".strip("."))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _walk_attributes(child, f"{path}[{index}]")


def _references_from_character(character: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "reference_id": item["reference_id"],
            "image_sha256": item["sha256"],
            "approval_state": "approved" if item.get("approved") else "unverified",
            "requested_orientation": item.get("view"),
            "verified_orientation": item.get("verified_view"),
            "appearance_revision": character["canonical_appearance"]["revision"],
        }
        for item in character.get("face_references", [])
    ]


def _portable_anchor(item: dict[str, Any]) -> dict[str, Any]:
    allowed = {"reference_id", "image_sha256", "approval_state", "requested_orientation", "verified_orientation", "intended_expression", "verified_expression"}
    return {key: deepcopy(value) for key, value in item.items() if key in allowed}


def _sanitize_appearance(appearance: dict[str, Any], *, portable: bool) -> dict[str, Any]:
    result = {
        "revision": appearance["revision"],
        "fingerprint": appearance.get("fingerprint"),
        "checkpoint": {key: value for key, value in appearance["checkpoint"].items() if key in ({"name"} if portable else {"name", "sha256"})},
        "sliders": [],
    }
    for order, slider in enumerate(appearance.get("sliders", [])):
        entry = {"stack_order": order, "slider_id": slider["slider_id"], "weight": slider["weight"], "enabled": slider.get("enabled", True)}
        result["sliders"].append(entry)
    if not portable:
        result["ip_adapter"] = {key: value for key, value in appearance.get("ip_adapter", {}).items() if not key.endswith("_path") and key not in {"reference_path", "staged_path"}}
    return result


def _identity_trait_values(dna: dict[str, Any]) -> list[str]:
    traits = dna["identity_invariants"].get("permanent_traits", {}).get("value", [])
    values = list(traits) if isinstance(traits, list) else [str(traits)]
    for key, item in sorted(dna["identity_invariants"].items()):
        if key in {"permanent_traits", "trigger", "class_noun"}:
            continue
        value = item.get("value")
        if value and str(value) not in values:
            values.append(str(value))
    return values


def _string_segments(value: Any) -> list[str]:
    if isinstance(value, list):
        result: list[str] = []
        for item in value:
            result.extend(_string_segments(item))
        return result
    text = str(value or "").strip()
    return [text] if text else []


def _deduplicate_segments(values: list[str]) -> list[str]:
    unique: list[str] = []
    seen: set[str] = set()
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            unique.append(value)
    # A fragment adds nothing when it is already an exact comma-delimited trait
    # inside a richer segment. Keep near-matches: they may carry a meaningful
    # qualifier (for example, "broad expressive prominent nose").
    component_sets = {
        value: {part.strip().casefold() for part in value.split(",") if part.strip()}
        for value in unique
    }
    return [
        value for value in unique
        if not any(
            value.casefold() in component_sets[other]
            or (len(value) <= 4 and other.casefold().startswith(value.casefold() + "-"))
            for other in unique
            if other != value
        )
    ]
