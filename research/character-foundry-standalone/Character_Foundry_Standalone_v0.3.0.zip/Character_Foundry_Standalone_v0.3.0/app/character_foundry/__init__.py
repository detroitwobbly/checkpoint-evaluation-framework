"""Character Factory foundation."""

__version__ = "0.3.0"

