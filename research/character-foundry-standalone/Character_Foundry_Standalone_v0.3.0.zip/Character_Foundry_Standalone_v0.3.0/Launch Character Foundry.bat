@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"

where py >nul 2>nul
if not errorlevel 1 (
  py -3 app\launch.py --config config\settings.json
  goto finished
)

where python >nul 2>nul
if not errorlevel 1 (
  python app\launch.py --config config\settings.json
  goto finished
)

echo.
echo Character Foundry requires Python 3.11 or newer.
echo Install Python from https://www.python.org/downloads/windows/ and try again.
pause
exit /b 1

:finished
if errorlevel 1 (
  echo.
  echo Character Foundry failed to start. The error is shown above.
  pause
)
