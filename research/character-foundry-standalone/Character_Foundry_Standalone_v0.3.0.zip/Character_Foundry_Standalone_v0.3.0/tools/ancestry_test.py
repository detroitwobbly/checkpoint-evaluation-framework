from __future__ import annotations

import json
import sys
import tempfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from character_foundry.descriptors import load_descriptor_catalog  # noqa: E402
from character_foundry.foundry import (  # noqa: E402
    build_wildcard_export,
    generate_draft,
    normalize_draft,
    resolve_ancestry_background,
    validate_ancestry_selection,
)
from character_foundry.registry import load_registry  # noqa: E402


def main() -> int:
    catalog = load_descriptor_catalog(ROOT / "config" / "descriptors.json")
    ancestry_catalog = catalog["ancestry_background"]
    registry = load_registry(ROOT / "config" / "slider_registry.json")

    first = generate_draft(137, registry, descriptor_catalog=catalog)
    again = generate_draft(137, registry, descriptor_catalog=catalog)
    assert first["ancestry_background"] == again["ancestry_background"]
    assert first["fingerprint"] == again["fingerprint"]
    assert first["portrait_prompt"].count(" ancestry") == 1
    assert "ancestry_background" in first["character_dna"]["identity_invariants"]

    group_counts: Counter[str] = Counter()
    group_entry_counts: Counter[str] = Counter()
    for seed in range(10_000):
        state, _ = resolve_ancestry_background(seed, ancestry_catalog)
        group_counts[str(state["broad_group"])] += 1
        if state["broad_group"] == "european":
            group_entry_counts[state["specific_backgrounds"][0]] += 1
    enabled_groups = [group for group in ancestry_catalog["groups"] if group.get("random_enabled", True)]
    expected = 10_000 / len(enabled_groups)
    assert all(abs(count - expected) < expected * 0.16 for count in group_counts.values()), group_counts
    european_total = sum(group_entry_counts.values())
    assert european_total > 0
    assert all(abs(count - european_total / 2) < european_total * 0.10 for count in group_entry_counts.values())

    selected = validate_ancestry_selection(
        {"selection_mode": "catalog", "specific_backgrounds": ["Irish"]}, ancestry_catalog
    )
    group_locked, locks = resolve_ancestry_background(
        9001,
        ancestry_catalog,
        current=selected,
        lock_state={"broad_group": True, "specific_backgrounds": False},
        regenerate="specific",
    )
    assert group_locked["broad_group"] == "european"
    assert locks == {"broad_group": True, "specific_backgrounds": False}
    fully_locked, _ = resolve_ancestry_background(
        9002,
        ancestry_catalog,
        current=selected,
        lock_state={"broad_group": True, "specific_backgrounds": True},
        regenerate="all",
    )
    assert fully_locked == selected
    preserved, _ = resolve_ancestry_background(
        9003, ancestry_catalog, current=selected, preserve_current=True
    )
    assert preserved == selected

    mixed = validate_ancestry_selection(
        {"selection_mode": "mixed", "specific_backgrounds": ["Japanese", "Irish"]}, ancestry_catalog
    )
    assert mixed["prompt_phrase"] == "Japanese and Irish ancestry"
    assert mixed["warnings"]
    mixed_draft = generate_draft(
        812,
        registry,
        descriptor_catalog=catalog,
        ancestry_background=mixed,
        regenerate_fields=[],
    )
    assert mixed_draft["portrait_prompt"].count("Japanese and Irish ancestry") == 1
    for invalid in (
        {"selection_mode": "mixed", "specific_backgrounds": ["Irish", "Irish"]},
        {"selection_mode": "mixed", "specific_backgrounds": ["Irish", "Greek"]},
    ):
        try:
            validate_ancestry_selection(invalid, ancestry_catalog)
            raise AssertionError("Invalid mixed ancestry selection was accepted")
        except ValueError:
            pass

    custom = validate_ancestry_selection(
        {"selection_mode": "custom", "custom_background": "Acadian"}, ancestry_catalog
    )
    assert custom["prompt_phrase"] == "Acadian ancestry"
    unspecified = validate_ancestry_selection({"selection_mode": "unspecified"}, ancestry_catalog)
    no_ancestry = generate_draft(
        813,
        registry,
        descriptor_catalog=catalog,
        ancestry_background=unspecified,
        regenerate_fields=[],
    )
    assert " ancestry" not in no_ancestry["portrait_prompt"]

    legacy = {
        "schema_version": "character-factory.foundry-draft.v0.2",
        "draft_id": "legacy-example",
    }
    migrated = normalize_draft(legacy)
    assert migrated["ancestry_background"]["selection_mode"] == "unspecified"
    assert "ancestry_background" not in legacy

    wildcard = build_wildcard_export(first, descriptor_catalog=catalog)
    assert wildcard["categories"]["ancestry_background"]
    assert "__foundry_ancestry_background__ ancestry" in wildcard["portrait_template"]
    assert "two-tier weighting" in wildcard["ancestry_sampling_note"]

    with tempfile.TemporaryDirectory(prefix="foundry-v01-catalog-", dir=ROOT / "tools") as temp:
        legacy_catalog = json.loads((ROOT / "config" / "descriptors.json").read_text(encoding="utf-8"))
        legacy_catalog["schema_version"] = "character-foundry.descriptor-catalog.v0.1"
        legacy_catalog.pop("ancestry_background")
        legacy_catalog["attributes"].pop("body_shape")
        path = Path(temp) / "descriptors.json"
        path.write_text(json.dumps(legacy_catalog), encoding="utf-8")
        loaded = load_descriptor_catalog(path)
        assert loaded["ancestry_background"]["groups"] == []

    print("Character Foundry ancestry/background tests passed")
    print(f"Broad-group sample counts: {dict(sorted(group_counts.items()))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
