from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT.parent
ZIP_PATH = DIST / f"{ROOT.name}.zip"
SHA_PATH = DIST / f"{ROOT.name}.zip.sha256"
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache"}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def package_files() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file()
        and path.name != "manifest.json"
        and not any(part in EXCLUDED_PARTS for part in path.parts)
        and path.suffix.lower() not in {".pyc", ".pyo"}
        and not ("data" in path.parts and "characters" in path.parts and path.suffix.lower() == ".json")
        and not ("output" in path.parts and path.suffix.lower() != ".keep")
    )


def main() -> int:
    files = package_files()
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    if not version:
        raise ValueError("VERSION is empty")
    manifest = {
        "schema_version": "character-foundry.portable-package-manifest.v0.2",
        "package_name": "Character Foundry Standalone",
        "version": version,
        "product": "Local browser app for reproducible portrait and full-body prompt generation",
        "entry_points": ["Launch Character Foundry.bat", "Test Character Foundry.bat"],
        "runtime": {"python": ">=3.11", "third_party_dependencies": []},
        "capabilities": [
            "seeded character drafts",
            "editable descriptor and ancestry catalog",
            "two-tier ancestry/background sampling",
            "catalog, mixed, custom, and unspecified ancestry modes",
            "independent ancestry and visible-trait locks",
            "optional validated whole-body build and body-shape controls",
            "explicit morphology randomization without population-frequency claims",
            "per-attribute locks and rerolls",
            "manual canonical edits",
            "portrait prompt",
            "full-body prompt",
            "optional external LoRA slider tags",
            "draft save/load and legacy migration",
            "Character DNA ancestry persistence",
            "wildcard export",
        ],
        "exclusions": [
            "image generation backend",
            "model files",
            "probe image collections",
            "private drafts",
            "Character Factory promotion",
            "training",
            "CEF evaluation",
        ],
        "checksum_policy": "files lists every packaged file except manifest.json itself to avoid a circular checksum",
        "files": [
            {
                "path": path.relative_to(ROOT).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": digest(path),
            }
            for path in files
        ],
    }
    (ROOT / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    archive_files = sorted([ROOT / "manifest.json", *files])
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in archive_files:
            archive.write(path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix())
    zip_sha = digest(ZIP_PATH)
    SHA_PATH.write_text(f"{zip_sha}  {ZIP_PATH.name}\n", encoding="ascii")
    print(ZIP_PATH)
    print(f"SHA-256: {zip_sha}")
    print(f"Packaged files: {len(archive_files)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
