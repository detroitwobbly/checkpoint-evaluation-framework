from __future__ import annotations

import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from character_foundry.descriptors import load_descriptor_catalog  # noqa: E402
from character_foundry.foundry_web import _render  # noqa: E402
from character_foundry.registry import load_registry  # noqa: E402


def main() -> int:
    node = shutil.which("node")
    if node is None:
        print("Node is unavailable; JavaScript syntax check skipped")
        return 0
    registry = load_registry(ROOT / "config" / "slider_registry.json")
    catalog = load_descriptor_catalog(ROOT / "config" / "descriptors.json")
    page = _render(registry, catalog)
    matches = re.findall(r"<script>(.*?)</script>", page, flags=re.DOTALL | re.IGNORECASE)
    if len(matches) != 1:
        raise AssertionError(f"Expected one inline script, found {len(matches)}")
    with tempfile.TemporaryDirectory(prefix="foundry-js-", dir=ROOT / "tools") as temp:
        script = Path(temp) / "foundry.js"
        script.write_text(matches[0], encoding="utf-8")
        subprocess.run([node, "--check", str(script)], check=True)
    print("Character Foundry JavaScript syntax test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
