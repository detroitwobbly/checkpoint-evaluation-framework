from __future__ import annotations

import ast
import importlib
import json
import pkgutil
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
APP_ROOT = ROOT / "app"
PACKAGE_ROOT = APP_ROOT / "character_foundry"
sys.path.insert(0, str(APP_ROOT))


def main() -> int:
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    package = importlib.import_module("character_foundry")
    assert package.__version__ == version, (package.__version__, version)
    assert f"v{version}" in (ROOT / "README.md").read_text(encoding="utf-8").splitlines()[0]

    imported = ["character_foundry"]
    for module in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
        importlib.import_module(module.name)
        imported.append(module.name)

    unresolved: list[str] = []
    for path in sorted(PACKAGE_ROOT.rglob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom) or node.level != 1 or not node.module:
                continue
            candidate_file = path.parent / f"{node.module.split('.')[0]}.py"
            candidate_package = path.parent / node.module.split(".")[0] / "__init__.py"
            if not candidate_file.is_file() and not candidate_package.is_file():
                unresolved.append(f"{path.relative_to(ROOT)}:{node.lineno}: from .{node.module}")
    assert not unresolved, "Unresolved packaged relative imports:\n" + "\n".join(unresolved)

    from character_foundry.dna import DNAValidationError, approve_imported_identity

    try:
        approve_imported_identity(Path("unused"), {}, approved_keys=[], registry={})
    except DNAValidationError as exc:
        assert "only in Character Factory" in str(exc)
    else:
        raise AssertionError("Standalone Factory-only DNA approval did not fail closed")

    ancestry_doc = (ROOT / "docs" / "ANCESTRY_BACKGROUND.md").read_text(encoding="utf-8").casefold()
    assert "draft schema v0.3" in ancestry_doc
    assert "not the application" in ancestry_doc

    manifest_path = ROOT / "manifest.json"
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert manifest["version"] == version

    print(f"Character Foundry distribution audit passed ({len(imported)} modules; version {version})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
