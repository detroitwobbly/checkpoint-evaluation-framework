from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from character_foundry.descriptors import load_descriptor_catalog  # noqa: E402
from character_foundry.foundry import (  # noqa: E402
    BODY_BUILD_OPTIONS,
    BODY_SHAPE_OPTIONS,
    DRAFT_SCHEMA,
    compose_foundry_prompts,
    generate_draft,
    normalize_draft,
)
from character_foundry.registry import load_registry  # noqa: E402
from character_foundry.foundry_web import _render  # noqa: E402


def main() -> int:
    registry = load_registry(ROOT / "config" / "slider_registry.json")
    catalog = load_descriptor_catalog(ROOT / "config" / "descriptors.json")
    page = _render(registry, catalog)
    assert "id='attr-body_build'" in page and "id='attr-body_shape'" in page
    assert ">Unspecified</option>" in page
    assert "Plus-sized" in page and "Inverted triangle" in page
    assert "The randomize buttons explicitly sample the tested list uniformly" in page
    draft = generate_draft(4242, registry, descriptor_catalog=catalog, slider_selections=[])

    assert draft["schema_version"] == DRAFT_SCHEMA
    assert draft["attributes"]["body_build"] == ""
    assert draft["attributes"]["body_shape"] == ""
    assert all(value not in draft["portrait_prompt"] for value in BODY_BUILD_OPTIONS + BODY_SHAPE_OPTIONS)
    assert all(value not in draft["full_body_prompt"] for value in BODY_BUILD_OPTIONS + BODY_SHAPE_OPTIONS)

    base = dict(draft["attributes"])

    build_only = dict(base, body_build="a plus-sized figure", body_shape="")
    prompts = compose_foundry_prompts(build_only, [], ancestry_background=draft["ancestry_background"])
    assert prompts["portrait_prompt"].count("a plus-sized figure") == 1
    assert prompts["full_body_prompt"].count("a plus-sized figure") == 1

    shape_only = dict(base, body_build="", body_shape="a pear-shaped figure")
    prompts = compose_foundry_prompts(shape_only, [], ancestry_background=draft["ancestry_background"])
    assert prompts["portrait_prompt"].count("a pear-shaped figure") == 1
    assert prompts["full_body_prompt"].count("a pear-shaped figure") == 1

    combined = dict(
        base,
        body_build="a muscular build",
        body_shape="an hourglass-shaped figure",
    )
    prompts = compose_foundry_prompts(combined, [], ancestry_background=draft["ancestry_background"])
    phrase = "a muscular build and an hourglass-shaped figure"
    assert prompts["portrait_prompt"].count(phrase) == 1
    assert prompts["full_body_prompt"].count(phrase) == 1
    forbidden = ("Kinetic", "breast", "broad shoulders", "narrow waist", "full thighs")
    assert not any(term.casefold() in prompts["portrait_prompt"].casefold() for term in forbidden)
    assert not any(term.casefold() in prompts["full_body_prompt"].casefold() for term in forbidden)

    rerolled = generate_draft(
        4243,
        registry,
        descriptor_catalog=catalog,
        canonical_attributes=base,
        regenerate_fields=["body_build"],
        slider_selections=[],
    )
    assert rerolled["attributes"]["body_build"] in BODY_BUILD_OPTIONS
    assert rerolled["attributes"]["body_shape"] == ""

    legacy = normalize_draft({
        "schema_version": "character-factory.foundry-draft.v0.3",
        "attributes": {"body_build": "compact stocky physique with sturdy limbs"},
    })
    assert legacy["attributes"]["body_build"] == "compact stocky physique with sturdy limbs"
    assert legacy["attributes"]["body_shape"] == ""

    print("Character Foundry morphology regression test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
