# Character Foundry Standalone v0.3.0

Character Foundry is a local browser application for inventing reproducible character concepts and producing clean portrait and full-body prompts. It preserves a seeded canonical character description while you lock, edit, or reroll individual traits.

This package is the prompt-generation portion of Character Factory. It does **not** generate images, call Forge or ComfyUI, train LoRAs, validate visual identity, or include model files. Copy its prompts into your preferred SDXL interface.

## Quick start (Windows)

1. Install Python 3.11 or newer from <https://www.python.org/downloads/windows/> if it is not already installed. No pip packages are required.
2. Extract the entire folder to any writable location.
3. Double-click `Test Character Foundry.bat` once. It should report `Character Foundry self-test passed`.
4. Double-click `Launch Character Foundry.bat`.
5. The browser opens at <http://127.0.0.1:8793/>. Leave the console window open while using Foundry. Press `Ctrl+C` in it to stop the server.

If the browser does not open automatically, visit the address above manually.

## Normal workflow

1. Choose a seed, adult age range, gender constraint, and plausible/eccentric/imaginative mode.
2. Select a catalog, mixed, custom, or unspecified ancestry/background. Ancestry is stored separately from visible traits.
3. Optionally select a whole-body build and body shape. Both default to Unspecified.
4. Generate a draft.
5. Lock traits that define the character. Edit or reroll the remaining traits.
6. Enable only the appearance sliders you actually have installed and choose their weights.
7. Copy either the Portrait or Full Body prompt into Forge, A1111, or another UI that accepts A1111-style LoRA tags.
8. Save the draft to preserve its DNA, settings, locks, prompts, and fingerprint.
9. Optionally export a wildcard package.

Saved drafts are written to `data/characters/`. Wildcard packages are written to `output/wildcards/`.

## Editing the descriptor library

`config/descriptors.json` is the editable vocabulary used for seeded character generation. Each key under `attributes` corresponds to a Foundry feature section such as `nose`, `eyes`, `skin`, `hair_style`, `body_build`, or `body_shape`.

- Add a quoted JSON string to make a new descriptor available.
- Edit a string to change its wording.
- Remove a string to retire it.
- Reorder strings to change the deterministic seed-to-choice mapping.
- Keep every feature section present and non-empty; keep JSON commas and quotes valid.

Restart Foundry after saving the file. The loader rejects empty sections, duplicate entries, missing sections, and invalid JSON instead of silently generating from a damaged catalog. Saved drafts record the descriptor catalog version and fingerprint used to create them.

The \`ancestry_background\` section is also editable. Each enabled group needs a unique \`id\`, a display \`label\`, and at least one entry with a unique \`id\`, \`label\`, and concise \`prompt_phrase\`. Keep warnings and probe limitations attached to the entries they describe. The loader accepts the older v0.1 catalog schema for compatibility; it supplies an unspecified ancestry state in memory.

## Body morphology

Foundry v0.3 separates optional whole-body build from optional body shape. Either may be selected alone, both may be combined, and Unspecified emits no morphology phrase. The production vocabulary is deliberately limited to tested whole-body concepts:

- Build: Average, Slender, Athletic, Muscular, Soft, Plump, Plus-sized.
- Shape: Hourglass, Pear, Apple, Inverted triangle.

Combined prompts use the tested syntax, for example `a muscular build and an hourglass-shaped figure`. Composability remains checkpoint-dependent and is not guaranteed.

New drafts leave both fields unspecified. The Randomize buttons are explicit creative operations that sample the corresponding tested list uniformly; Foundry does not claim demographic or population frequencies. Wildcard export preserves the selected morphology instead of silently randomizing it.

Regional anatomy and breast morphology are intentionally absent. Controlled probes did not demonstrate sufficiently isolated prompt control under ordinary clothed generation conditions. Downstream optional sliders may be used deliberately when installed, but Foundry never injects Kinetic or another morphology LoRA automatically. See `docs/BODY_MORPHOLOGY.md`.

## Ancestry / Ethnic Background

Foundry v0.2 stores ancestry as declared character-background metadata. It does not infer ancestry from images, authenticate representation, or bind ancestry to skin tone, facial geometry, hair, eyes, or body build.

- **Catalog:** chooses one tested specific background. Random rolls choose broad groups uniformly, then entries uniformly within the selected group.
- **Mixed ancestry:** explicitly combines two to four backgrounds from different broad groups. This is not randomly selected by default.
- **Custom:** accepts concise operator wording and marks it unvalidated.
- **Unspecified:** omits ancestry from generated prompts.
- **Locks:** the broad-group lock permits rerolling within a group; the specific-background lock preserves the complete selection.

Juggernaut frequently emphasized one component of mixed ancestry in the confirmation probe. Use mixed ancestry to preserve character background, then use Foundry's independent face, skin, and hair controls to author visible morphology. Never use explicit-parent wording such as “one A parent and one B parent” in prompts: it repeatedly generated multiple people in the controlled probe.

See \`docs/ANCESTRY_BACKGROUND.md\`, \`docs/ANCESTRY_PROBE_REPORT.md\`, and \`docs/MIGRATION_v0.2.md\` for evidence, limitations, and compatibility details.

## Reproducibility

The same Foundry version, registry, seed, constraints, canonical edits, locks, and slider selections produce the same draft. The application records a deterministic draft ID and fingerprint. Image results still depend on your checkpoint, VAE, LoRAs, sampler, scheduler, steps, CFG, resolution, seed, and generation software.

For Alex's tested slider workflow, DPM++ 2M SDE, Karras, 32 steps, CFG 7 is a useful starting point, not a requirement or backend setting in Foundry.

## Slider registry and model files

`config/slider_registry.json` contains slider metadata, validated weight ranges, promptable names, warnings, and known hashes. The `external_models/...` paths are portable identifiers only; Foundry does not open or verify those model files.

No LoRAs are bundled. Install the desired LoRAs in your generation UI. If your installed model filename differs from a registry item's `prompt_name`, edit that `prompt_name` to the filename stem your UI recognizes.

Tan Lines is retained as documented evidence but disabled in this portable registry because local testing found artifact leakage. It can be deliberately re-enabled by changing its `selectable` field after recalibration.

## Configuration

Edit `config/settings.json` while Foundry is stopped:

- `registry_path`: slider registry, relative to the package root or absolute.
- `descriptor_catalog_path`: editable feature vocabulary.
- `workspace_path`: saved draft directory.
- `output_path`: wildcard export directory.
- `host`: keep `127.0.0.1` for a private local application.
- `port`: default `8793`; change it if another program uses that port.
- `open_browser`: whether launch opens the default browser.

Relative paths make the extracted folder relocatable.

## Compatibility and boundaries

- Supported host: Windows 10/11.
- Runtime: CPython 3.11 or newer; tested here on Python 3.14.5.
- Browser: a current Chromium, Firefox, or Edge build.
- Network: no internet access is required. The server binds to localhost by default.
- Generation backends: no direct integration. Generated prompts use `<lora:name:weight>` syntax commonly accepted by Forge/A1111.
- Character Factory promotion, image references, contact sheets, turnaround generation, image review, captioning, training, and CEF evaluation are not part of this standalone slice.
- Draft schemas v0.1 through v0.4 remain loadable. Legacy free-text body-build values are preserved as custom selections when a saved draft is opened.

## Troubleshooting

- **Python not found:** install Python 3.11+ and enable the Python launcher or add Python to PATH.
- **Port already in use:** change `port` in `config/settings.json`, then launch again.
- **LoRA tag has no effect:** install the LoRA and ensure the tag name matches the model filename recognized by your generation UI.
- **Draft does not save:** extract the package to a writable folder and ensure security software is not blocking Python.
- **Browser shows an old page:** close the prior Foundry console, verify the configured port, then hard-refresh the browser.
- **Need a clean reset:** back up and remove only the JSON files in `data/characters/`; the application code and registry are unaffected.

## Integrity

`manifest.json` inventories package files and their SHA-256 hashes, excluding itself to avoid a circular checksum. The ZIP is accompanied by an external `.sha256` file.

## License

Distributed under the GNU Affero General Public License v3.0; see `LICENSE`. Source code is included in `app/character_foundry/`.
