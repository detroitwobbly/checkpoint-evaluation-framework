# Changelog

## 0.3.0 — 2026-11-24

- Added optional, separately persisted whole-body build and body-shape selections.
- Added exact tested prompt assembly for build-only, shape-only, and combined morphology.
- Defaulted new and legacy-missing morphology fields to Unspecified without emitting prompt text.
- Added explicit morphology randomization controls; no implicit population frequencies are assigned.
- Preserved legacy free-text body-build values when older drafts are loaded.
- Kept morphology fixed during wildcard export instead of silently randomizing it.
- Excluded unsupported rectangular, regional-anatomy, and breast-morphology controls.
- Confirmed that no experimental Kinetic or other LoRA dependency is injected.
- Added morphology regression and HTTP save/load round-trip coverage.

## 0.2.1 — 2026-11-22

- Repaired the standalone DNA module boundary and corrected ancestry documentation versioning.
- Added clean-room distribution import and launch audits.

