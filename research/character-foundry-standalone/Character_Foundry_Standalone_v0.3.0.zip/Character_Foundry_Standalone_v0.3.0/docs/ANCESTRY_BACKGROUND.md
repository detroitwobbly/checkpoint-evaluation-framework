# Ancestry / Ethnic Background

Character Foundry treats ancestry as user-declared creative character metadata. It is not a race classifier, an inference about a real person, a guarantee of visual authenticity, or a mapping from ancestry to fixed physical traits.

## State model

Every draft using schema `character-factory.foundry-draft.v0.3` contains the
following state. Draft schema v0.3 was introduced by the Character Foundry
Standalone v0.2 release line; it is a data-schema version, not the application
release number.

- \`ancestry_background.selection_mode\`: \`catalog\`, \`mixed\`, \`custom\`, or \`unspecified\`;
- \`broad_group\`: catalog group ID, \`mixed_ancestry\`, \`custom\`, or null;
- \`specific_backgrounds\`: one catalog label, or two to four labels for mixed ancestry;
- \`custom_background\`: operator text only in custom mode;
- \`prompt_phrase\`: the normalized phrase inserted once in prompts;
- \`warnings\`: checkpoint-specific limitations from the catalog;
- \`ancestry_lock_state.broad_group\` and \`.specific_backgrounds\`.

DNA stores the structured object as the separate \`identity_invariants.ancestry_background\` value. Mixed and custom selections receive \`user_declared\` provenance; seeded catalog rolls receive \`generated_intent\` provenance.

## Sampling

Seeded catalog rolls choose uniformly among enabled \`random_enabled\` broad groups, then uniformly among enabled entries in that group. Mixed, custom, and unspecified modes are not included in random sampling by default. This intentionally favors coverage rather than real-world population weighting.

Third-party flat wildcard engines cannot preserve two-tier weighting. Wildcard exports therefore include a flattened compatibility list plus an explicit sampling warning.

## Prompting and independence

Standard phrasing is “a 32-year-old adult woman of Japanese ancestry.” Mixed phrasing is “a 32-year-old adult woman of Japanese and Irish ancestry.” Unspecified ancestry adds nothing.

Ancestry never silently changes or locks skin, eyes, face shape, nose, mouth, hair, body build, clothing, or sliders. Those controls are the authoritative visible-trait controls, particularly for mixed-heritage characters.

## Editing the catalog

Edit \`config/descriptors.json\` while Foundry is stopped. The initial production catalog contains only specific backgrounds exercised in the controlled probe. New entries may be added, but should be marked with an honest status and notes until reviewed. Restart Foundry after changes.

Avoid terms that only work by adding costume, scenery, religious symbols, flags, landmarks, face paint, or caricature. A culturally meaningful identity can remain useful metadata even if a checkpoint has weak visual specificity for it.
