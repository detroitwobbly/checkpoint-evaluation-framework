# Migration notes — v0.1.0 to v0.2.0

- The portable folder is a new side-by-side release. v0.1.0 is not overwritten.
- Draft schemas v0.1 and v0.2 remain loadable.
- Loading a legacy draft supplies an unlocked, unspecified ancestry state in memory. Loading alone does not rewrite the file or its fingerprint.
- Saving that draft is an explicit migration: it writes draft schema v0.3, stores ancestry state and locks, updates DNA, and computes a new fingerprint.
- Existing canonical attributes, visible-trait locks, prompts, sliders, and descriptor values are preserved.
- Descriptor catalog v0.1 remains loadable and receives an ancestry-disabled compatibility view in memory. Catalog v0.2 adds the separately validated ancestry section.
- Existing wildcard export remains functional. v0.2 adds ancestry state, lock metadata, a flat compatibility wildcard when applicable, and a warning that flat engines do not preserve group-first sampling.
- No checkpoint, LoRA, generated contact sheet, or private character draft is included.
