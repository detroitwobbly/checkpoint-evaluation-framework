# Body morphology vocabulary

Character Foundry v0.3 closes the 2026-11-24 body-morphology discovery phase and promotes only whole-body vocabulary that was suitable for ordinary character production.

## Production controls

Build and shape are independent optional fields. Missing or empty values mean Unspecified and emit no prompt text.

| Build label | Prompt phrase |
|---|---|
| Average | `an average build` |
| Slender | `a slender build` |
| Athletic | `an athletic build` |
| Muscular | `a muscular build` |
| Soft | `a soft build` |
| Plump | `a plump figure` |
| Plus-sized | `a plus-sized figure` |

| Shape label | Prompt phrase |
|---|---|
| Hourglass | `an hourglass-shaped figure` |
| Pear | `a pear-shaped figure` |
| Apple | `an apple-shaped figure` |
| Inverted triangle | `an inverted triangle body shape` |

When both fields are present, Foundry uses the tested syntax `<build> and <shape>`. The two controls are partially composable and checkpoint-dependent; the application does not promise independent anatomical construction.

## Exclusions

- Rectangular shape was effectively inert in the tested checkpoint and is not exposed.
- Regional anatomy is retained only as research evidence; it is not a production control.
- Breast size, shape, spacing, placement, and symmetry descriptors are excluded. Clothed probes entangled the requested anatomy with garment construction, presentation, framing, pose, apparent size, and torso silhouette.
- Kinetic was an experimental pose-control instrument and is never injected into production prompts.

An installed external slider may still be selected deliberately in the Appearance Control Box. Such sliders remain separate from Foundry's semantic body vocabulary.

These dispositions are checkpoint-specific research decisions, not universal claims about SDXL.

