# Ancestry prompt confirmation probe

**Backend:** Juggernaut XL Ragnarok 2.0  
**Reference settings:** 1024×1024, DPM++ 2M SDE Karras, 30 steps, CFG 7, empty negative prompt, no LoRAs  
**Authority:** human review plus descriptive assistant observations; no ethnicity recognition or automated ancestry scoring

## Evidence summary

Phase A produced 53 hash-verified images: two fixed female seeds across a neutral control and selected broad/specific labels, plus a smaller male cross-check. The charcoal shirt, gray studio background, ordinary portrait composition, and photographic treatment remained stable. No broad pattern of flags, landmarks, exotic scenery, ceremonial clothing, grass skirts, igloos, face paint, or costume substitution was observed.

The retained initial catalog is limited to labels actually exercised in that probe: Japanese, Tamil, Filipino, Yoruba, Amazigh, Persian/Iranian, Kazakh, Irish, Greek, Diné/Navajo, Quechua, Samoan, and Māori.

Known limitations are preserved in \`config/descriptors.json\`:

- Tamil added a bindi in both female seeds, but not in the male cross-check.
- Yoruba coupled strongly with particular hair presentations; explicit hair controls remain independent.
- Kazakh overlapped visibly with the checkpoint's East Asian priors.
- ancestry wording changed skin and hair alongside facial variation even though these were not explicitly requested.
- two seeds demonstrate prompt response, not authentic or unique real-world morphology.

## Mixed ancestry wording

Phases A and B tested Japanese/Irish and Yoruba/English combinations. “of A and B ancestry,” “of mixed A and B ancestry,” and “with A and B family ancestry” retained a single subject, but one named background visually dominated. None demonstrated dependable balanced blending.

“with one A parent and one B parent” generated multiple people in every tested cell and is rejected for production prompting.

Phase C tested concise “biracial A-B woman” and “A-B biracial heritage” wording. It retained a single person but still did not demonstrate reliable balanced morphology. The production app therefore uses the simpler “A and B ancestry” phrase, labels mixed prompting experimental, and directs operators to independent visible-trait controls.

Probe contact sheets and generation receipts remain outside the portable ZIP under the Character Factory ancestry probe report directory. They are intentionally not bundled with the lightweight application.
