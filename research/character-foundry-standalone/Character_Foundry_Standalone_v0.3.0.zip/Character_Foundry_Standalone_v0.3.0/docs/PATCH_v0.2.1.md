# Character Foundry Standalone v0.2.1

This maintenance release repairs the standalone distribution boundary without
changing prompt generation or ancestry behavior.

- Removed unresolved lazy imports of the excluded Character Factory project
  module from the standalone DNA approval compatibility function.
- The compatibility function now raises a clear product-boundary error: the
  standalone app can parse and preserve pending imported-DNA reports, while
  approval and identity revision remain Character Factory operations.
- Clarified that `character-factory.foundry-draft.v0.3` is the draft schema
  introduced in the v0.2 application line, not an application version claim.
- Corrected the packaged Python module version.
- Added an independent module/import/version distribution audit and made it
  part of `Test Character Foundry.bat`.

The release ZIP is validated after extraction in a clean directory outside the
development repository.
