# Validation record

The package is accepted only if all of the following pass:

1. Deterministic ancestry sampling, approximately equal group frequency, uniform within-group selection, broad/specific locks, unrelated reroll preservation, mixed/custom/unspecified modes, duplicate rejection, prompt placement, DNA, legacy normalization, catalog v0.1 compatibility, and wildcard metadata.
2. Portable self-test from the distribution directory.
3. Local HTTP launch and successful `GET /`, deterministic `POST /api/generate`, mixed-ancestry `POST /api/compose`, save, and wildcard export.
4. Save and wildcard export endpoints write only to configured package-relative directories.
5. ZIP extraction to a different path containing spaces followed by the same self-test and HTTP probe.
6. Static scan finds no `C:/Users/palex`, Stability Matrix, OneDrive source path, CEF workspace dependency, bundled `.safetensors`, cache, or private draft JSON.
7. Every packaged Python module imports independently, every relative import resolves to a packaged module, package/version metadata agree, and the unavailable Factory-only DNA approval path raises a deliberate boundary error rather than `ModuleNotFoundError`.

Exact execution results are recorded in `validation_results.json` during packaging.
