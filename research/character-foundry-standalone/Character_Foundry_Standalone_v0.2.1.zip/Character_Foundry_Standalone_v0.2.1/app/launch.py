from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent.parent
APP_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_ROOT))

from character_foundry.foundry import generate_draft  # noqa: E402
from character_foundry.foundry_web import serve_foundry  # noqa: E402
from character_foundry.registry import load_registry  # noqa: E402
from character_foundry.descriptors import load_descriptor_catalog  # noqa: E402


def _settings(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("settings.json must contain a JSON object")
    return value


def _package_path(value: str) -> Path:
    candidate = Path(value)
    return candidate if candidate.is_absolute() else PACKAGE_ROOT / candidate


def main() -> int:
    parser = argparse.ArgumentParser(description="Launch the portable Character Foundry local web app")
    parser.add_argument("--config", type=Path, default=PACKAGE_ROOT / "config" / "settings.json")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if sys.version_info < (3, 11):
        raise SystemExit("Character Foundry requires Python 3.11 or newer")

    settings = _settings(args.config.resolve())
    registry_path = _package_path(settings["registry_path"]).resolve()
    workspace = _package_path(settings["workspace_path"]).resolve()
    output_root = _package_path(settings["output_path"]).resolve()
    descriptor_catalog_path = _package_path(settings["descriptor_catalog_path"]).resolve()
    registry = load_registry(registry_path)
    descriptor_catalog = load_descriptor_catalog(descriptor_catalog_path)

    if args.self_test:
        draft = generate_draft(
            137, registry,
            constraints={"gender": "female", "age_min": 28, "age_max": 45},
            descriptor_catalog=descriptor_catalog,
        )
        assert draft["draft_id"].startswith("foundry-137-")
        assert draft["ancestry_background"]["selection_mode"] == "catalog"
        assert draft["portrait_prompt"].count(" ancestry") == 1
        assert "ancestry_background" in draft["character_dna"]["identity_invariants"]
        print("Character Foundry self-test passed")
        print(f"Python: {sys.version.split()[0]}")
        print(f"Registry: {registry_path}")
        return 0

    serve_foundry(
        registry_path,
        workspace,
        output_root,
        descriptor_catalog_path,
        host=str(settings.get("host", "127.0.0.1")),
        port=int(settings.get("port", 8793)),
        open_browser=bool(settings.get("open_browser", True)),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
