"""Character Factory foundation."""

__version__ = "0.2.1"

