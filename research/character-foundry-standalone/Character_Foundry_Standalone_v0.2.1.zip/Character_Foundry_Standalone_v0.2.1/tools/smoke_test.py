from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

from character_foundry.foundry_web import serve_foundry  # noqa: E402


OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def request(url: str, payload: dict | None = None) -> dict | str:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    # A local clean-room test must not inherit a workstation HTTP proxy.
    with OPENER.open(req, timeout=3) as response:
        raw = response.read().decode("utf-8")
        return json.loads(raw) if payload is not None or url.endswith("/api/drafts") else raw


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="character-foundry-smoke-", dir=ROOT / "tools") as temp:
        temp_root = Path(temp)
        workspace = temp_root / "drafts"
        output = temp_root / "wildcards"
        port = 18793
        thread = threading.Thread(
            target=serve_foundry,
            args=(
                ROOT / "config" / "slider_registry.json",
                workspace,
                output,
                ROOT / "config" / "descriptors.json",
                "127.0.0.1",
                port,
            ),
            daemon=True,
        )
        thread.start()
        base = f"http://127.0.0.1:{port}"
        last_error: OSError | None = None
        for _ in range(30):
            try:
                page = request(base + "/")
                break
            except OSError as exc:
                last_error = exc
                time.sleep(0.1)
        else:
            raise RuntimeError(f"Local server did not become ready: {last_error!r}")
        assert "Character Foundry" in str(page)

        generated = request(base + "/api/generate", {
            "seed": 4242,
            "constraints": {"gender": "female", "age_min": 30, "age_max": 45, "mode": "eccentric"},
            "sliders": [],
            "prompt_mode": "portrait",
            "clothing_category": "simple_neutral",
        })
        assert isinstance(generated, dict) and generated["ok"]
        draft = generated["draft"]
        assert draft["portrait_prompt"] and draft["full_body_prompt"]
        assert draft["ancestry_background"]["selection_mode"] == "catalog"
        assert draft["portrait_prompt"].count(" ancestry") == 1

        composed = request(base + "/api/compose", {
            "attributes": draft["attributes"],
            "sliders": [],
            "clothing_category": "simple_neutral",
            "ancestry_background": {
                "selection_mode": "mixed",
                "specific_backgrounds": ["Japanese", "Irish"],
            },
        })
        assert isinstance(composed, dict) and composed["ok"]
        assert "Japanese and Irish ancestry" in composed["prompts"]["portrait_prompt"]
        saved = request(base + "/api/save", {"draft": draft})
        exported = request(base + "/api/export-wildcards", {"draft": draft})
        assert isinstance(saved, dict) and Path(saved["path"]).is_file()
        assert isinstance(exported, dict) and (Path(exported["path"]) / "manifest.json").is_file()

        unsafe = dict(draft)
        unsafe["draft_id"] = "../escape"
        try:
            request(base + "/api/save", {"draft": unsafe})
            raise AssertionError("Unsafe draft identifier was accepted")
        except urllib.error.HTTPError as exc:
            assert exc.code == 400

    print("Character Foundry HTTP smoke test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
