@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"

where py >nul 2>nul
if not errorlevel 1 (
  py -3 app\launch.py --config config\settings.json --self-test
  if errorlevel 1 goto finished
  py -3 tools\ancestry_test.py
  if errorlevel 1 goto finished
  py -3 tools\smoke_test.py
  goto finished
)

where python >nul 2>nul
if not errorlevel 1 (
  python app\launch.py --config config\settings.json --self-test
  if errorlevel 1 goto finished
  python tools\ancestry_test.py
  if errorlevel 1 goto finished
  python tools\smoke_test.py
  goto finished
)

echo Character Foundry requires Python 3.11 or newer.
exit /b 1

:finished
if errorlevel 1 pause
