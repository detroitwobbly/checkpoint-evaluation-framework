# Architecture inventory

## Included runtime

| Component | Purpose |
|---|---|
| `app/launch.py` | Reads portable settings, checks the runtime, runs self-test or starts the server. |
| `character_foundry/foundry_web.py` | Local `ThreadingHTTPServer`, inline browser UI, JSON endpoints, draft and wildcard persistence. |
| `character_foundry/foundry.py` | Deterministic draft generation, visible-trait and ancestry locks/rerolls, two-tier ancestry sampling, prompt composition, slider proposals, wildcard export. |
| `character_foundry/dna.py` | Character DNA attributes, validation, and deterministic fingerprints. Factory-only promotion remains lazy and unreachable in this package. |
| `character_foundry/registry.py` | Slider registry schema validation and proposal resolution. |
| `character_foundry/descriptors.py` | Loads and validates the owner-editable descriptor catalog. |
| `character_foundry/io.py` | Atomic JSON writes and stable SHA-256 digests. |

All runtime code uses Python's standard library. Browser HTML, CSS, and JavaScript are emitted by `foundry_web.py`; there is no Node build, database, cloud service, CEF dependency, or model runtime.

## HTTP surface

- `GET /` — application UI
- `GET /api/drafts` — list saved JSON drafts
- `POST /api/generate` — deterministic draft generation/reroll
- `POST /api/compose` — rebuild prompts after edits
- `POST /api/save` — save fingerprinted draft
- `POST /api/load` — load a saved draft
- `POST /api/export-wildcards` — write templates and wildcard categories

The server binds to `127.0.0.1` by default. Request bodies are limited to 2 MB, and persisted draft identifiers are restricted to safe filename characters.

## Extraction boundary

The package deliberately excludes Character Factory's ComfyUI, captioning, training, review, dataset, CEF, report, cache, log, and private-project modules. The only adaptation in extracted shared code is a lazy import for the unavailable Factory promotion transaction. The working source tree is unchanged.

The portable registry replaces workstation-specific absolute LoRA paths with `external_models/...` identifiers. No LoRA or checkpoint assets are bundled.

Feature descriptors, full-body clothing phrases, and structured ancestry groups are externalized in `config/descriptors.json`. Users can add, modify, reorder, or remove entries without changing Python. Catalog v0.2 validates ancestry group IDs, entry IDs and labels, prompt phrases, duplicate entries, and mixed-entry limits. The catalog is fingerprinted into generated draft provenance.

Ancestry is a sibling of the flat visible-attribute map, not another visible attribute. A draft stores one structured ancestry object plus separate broad/specific lock state. DNA stores that object as its own identity invariant. Legacy drafts receive an unspecified value only in memory until the operator explicitly saves.

## Current functional limits

Foundry provides prompt-level identity consistency, not image-conditioned identity consistency. It cannot promise that a checkpoint will render a trait, ancestry phrase, or slider as requested. Mixed ancestry is particularly dominance-prone and is not a morphology blender. Foundry has no reference image, backend, gallery, contact sheet, or visual QA system. Those remain Character Factory/CEF responsibilities.
