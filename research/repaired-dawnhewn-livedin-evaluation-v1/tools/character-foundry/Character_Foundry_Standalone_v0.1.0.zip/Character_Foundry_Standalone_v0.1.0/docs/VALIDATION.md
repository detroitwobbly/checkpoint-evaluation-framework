# Validation record

The package is accepted only if all of the following pass:

1. Original Foundry unit suite: deterministic seeds, lock preservation, manual edits, rerolls, prompt-mode stability, wildcard semantics, browser request ordering, slider range validation, and uncommitted DNA state.
2. Portable self-test from the distribution directory.
3. Local HTTP launch and successful `GET /` plus deterministic `POST /api/generate`.
4. Save and wildcard export endpoints write only to configured package-relative directories.
5. ZIP extraction to a different path containing spaces followed by the same self-test and HTTP probe.
6. Static scan finds no `C:/Users/palex`, Stability Matrix, OneDrive source path, CEF workspace dependency, bundled `.safetensors`, cache, or private draft JSON.

Exact execution results are recorded in `validation_results.json` during packaging.
