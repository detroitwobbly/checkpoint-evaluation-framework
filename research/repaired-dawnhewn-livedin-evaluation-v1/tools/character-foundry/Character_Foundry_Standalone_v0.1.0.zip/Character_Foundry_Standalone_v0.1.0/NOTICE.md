# Distribution notice

This is an extracted standalone distribution of the Character Foundry prompt-generation surface from Character Factory. It is packaged for external evaluation without private drafts, generated images, model weights, machine-specific paths, or Character Factory/CEF operational state.

The full source for the included web application is present in `app/character_foundry/`. No third-party Python packages or JavaScript libraries are included.
