from __future__ import annotations

from pathlib import Path
from typing import Any

from .foundry import OPTIONS
from .io import read_json, stable_digest


DESCRIPTOR_SCHEMA = "character-foundry.descriptor-catalog.v0.1"


def load_descriptor_catalog(path: Path) -> dict[str, Any]:
    value = read_json(path)
    if not isinstance(value, dict) or value.get("schema_version") != DESCRIPTOR_SCHEMA:
        raise ValueError(f"Unsupported descriptor catalog schema in {path}")
    attributes = value.get("attributes")
    clothing = value.get("clothing_categories")
    if not isinstance(attributes, dict) or set(attributes) != set(OPTIONS):
        raise ValueError(f"Descriptor catalog attributes must be exactly: {sorted(OPTIONS)}")
    for key, entries in attributes.items():
        if not isinstance(entries, list) or not entries:
            raise ValueError(f"Descriptor section {key!r} must be a non-empty list")
        if any(not isinstance(item, str) or not item.strip() for item in entries):
            raise ValueError(f"Descriptor section {key!r} contains an empty or non-text value")
        if len(entries) != len(set(entries)):
            raise ValueError(f"Descriptor section {key!r} contains duplicates")
    if not isinstance(clothing, dict) or not clothing:
        raise ValueError("Descriptor catalog clothing_categories must be a non-empty object")
    if any(not isinstance(key, str) or not key.strip() or not isinstance(text, str) or not text.strip()
           for key, text in clothing.items()):
        raise ValueError("Clothing category names and prompts must be non-empty text")
    result = dict(value)
    result["fingerprint"] = stable_digest({key: item for key, item in value.items() if key != "fingerprint"})
    return result
