from __future__ import annotations

import html
import json
import threading
import webbrowser
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .foundry import (
    ATTRIBUTE_KEYS,
    CLOTHING_CATEGORIES,
    SUPPORTED_DRAFT_SCHEMAS,
    build_wildcard_export,
    compose_foundry_prompts,
    generate_draft,
    resolve_foundry_sliders,
)
from .io import stable_digest, write_json_atomic
from .registry import load_registry
from .descriptors import load_descriptor_catalog


def serve_foundry(
    registry_path: Path,
    workspace: Path,
    output_root: Path | None = None,
    descriptor_catalog_path: Path | None = None,
    host: str = "127.0.0.1",
    port: int = 8793,
    *,
    open_browser: bool = False,
) -> None:
    registry = load_registry(registry_path.resolve())
    descriptor_catalog = load_descriptor_catalog(descriptor_catalog_path.resolve()) if descriptor_catalog_path else None
    workspace = workspace.resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    output_root = (output_root or (workspace / "wildcard_exports")).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            path = urlparse(self.path).path
            if path == "/":
                return self._html(_render(registry, descriptor_catalog))
            if path == "/api/drafts":
                drafts = sorted(item.name for item in workspace.glob("*.json") if item.is_file())
                return self._json({"ok": True, "drafts": drafts})
            self.send_error(404)

        def do_POST(self) -> None:  # noqa: N802
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
                if content_length < 0 or content_length > 2_000_000:
                    raise ValueError("Request body exceeds the 2 MB local-app limit")
                payload = json.loads(self.rfile.read(content_length) or b"{}")
                if self.path == "/api/generate":
                    draft = generate_draft(
                        int(payload["seed"]), registry,
                        constraints=payload.get("constraints"), locks=payload.get("locks"),
                        slider_selections=payload.get("sliders"),
                        canonical_attributes=payload.get("canonical_attributes"),
                        locked_attributes=payload.get("locked_attributes"),
                        regenerate_fields=payload.get("regenerate_fields"),
                        prompt_mode=payload.get("prompt_mode", "portrait"),
                        clothing_category=payload.get("clothing_category", "simple_neutral"),
                        descriptor_catalog=descriptor_catalog,
                    )
                    return self._json({"ok": True, "draft": draft})
                if self.path == "/api/compose":
                    sliders = resolve_foundry_sliders(registry, payload.get("sliders", []))
                    compiled = compose_foundry_prompts(
                        payload["attributes"], sliders,
                        clothing_category=payload.get("clothing_category", "simple_neutral"),
                        clothing_categories=(descriptor_catalog or {}).get("clothing_categories"),
                    )
                    return self._json({"ok": True, "prompts": compiled, "sliders": sliders})
                if self.path == "/api/save":
                    draft = payload["draft"]
                    if draft.get("schema_version") not in SUPPORTED_DRAFT_SCHEMAS:
                        raise ValueError("Unsupported Foundry draft")
                    draft.pop("fingerprint", None)
                    draft["fingerprint"] = stable_digest(draft)
                    draft_id = _safe_leaf(str(draft["draft_id"]))
                    target = workspace / f"{draft_id}.json"
                    with lock:
                        write_json_atomic(target, draft)
                    return self._json({"ok": True, "path": str(target)})
                if self.path == "/api/load":
                    name = Path(str(payload["name"])).name
                    target = workspace / name
                    if target.parent != workspace or not target.is_file():
                        raise ValueError("Saved Foundry draft was not found")
                    draft = json.loads(target.read_text(encoding="utf-8"))
                    if draft.get("schema_version") not in SUPPORTED_DRAFT_SCHEMAS:
                        raise ValueError("Unsupported Foundry draft")
                    return self._json({"ok": True, "draft": draft})
                if self.path == "/api/export-wildcards":
                    package = build_wildcard_export(payload["draft"], descriptor_catalog=descriptor_catalog)
                    draft_id = _safe_leaf(str(payload["draft"]["draft_id"]))
                    target = output_root / draft_id
                    with lock:
                        target.mkdir(parents=True, exist_ok=True)
                        write_json_atomic(target / "manifest.json", package)
                        (target / "portrait.txt").write_text(package["portrait_template"] + "\n", encoding="utf-8")
                        (target / "full_body.txt").write_text(package["full_body_template"] + "\n", encoding="utf-8")
                        categories = target / "wildcards"
                        categories.mkdir(exist_ok=True)
                        for key, values in package["categories"].items():
                            (categories / f"foundry_{key}.txt").write_text("\n".join(values) + "\n", encoding="utf-8")
                    return self._json({"ok": True, "path": str(target)})
                self.send_error(404)
            except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                self._json({"ok": False, "error": str(exc)}, 400)

        def log_message(self, format: str, *args: object) -> None:
            return

        def _json(self, value: object, status: int = 200) -> None:
            data = json.dumps(value).encode("utf-8")
            self.send_response(status); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

        def _html(self, value: str) -> None:
            data = value.encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    url = f"http://{host}:{port}/"
    try:
        server = ThreadingHTTPServer((host, port), Handler)
    except OSError as exc:
        if getattr(exc, "winerror", None) == 10048 or getattr(exc, "errno", None) in {48, 98, 10048}:
            print(f"Character Foundry port {port} is already in use. Opening the existing local address.", flush=True)
            if open_browser:
                webbrowser.open(url)
            return
        raise
    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    print(f"Character Foundry: {url}", flush=True)
    server.serve_forever()


def _safe_leaf(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", value):
        raise ValueError("Draft identifier contains unsupported characters")
    return value


def _render(registry: dict, descriptor_catalog: dict | None = None) -> str:
    sliders = []
    for item in registry.get("sliders", []):
        if not item.get("selectable"):
            continue
        low, high = item["validated_range"]
        warning = " · ".join(item.get("warnings", []))
        sliders.append(
            f"<div class='slider' data-id='{html.escape(item['slider_id'])}'>"
            f"<label><input class='slider-on' type='checkbox'> <b>{html.escape(item['display_name'])}</b></label>"
            f"<span>− {html.escape(item['negative_pole'])}<br>+ {html.escape(item['positive_pole'])}</span>"
            f"<input class='slider-weight' type='number' min='{low}' max='{high}' step='{item['step_size']}' value='{item['default_weight']}'>"
            f"<small>range {low}…{high} · {html.escape(item['role'])}<br>{html.escape(warning)}</small></div>"
        )
    attribute_rows = "".join(
        f"<div class='attr'><div class='attr-head'><label><input type='checkbox' class='lock' data-key='{key}'> "
        f"lock {html.escape(key.replace('_',' '))}</label><button class='tiny secondary' onclick='rerollOne(\"{key}\")'>reroll</button></div>"
        f"<textarea id='attr-{key}' data-key='{key}' oninput='editAttribute(this)'></textarea></div>"
        for key in ATTRIBUTE_KEYS
    )
    clothing_categories = CLOTHING_CATEGORIES if descriptor_catalog is None else descriptor_catalog["clothing_categories"]
    clothing_options = "".join(
        f"<option value='{html.escape(key)}'{' selected' if key == 'simple_neutral' else ''}>"
        f"{html.escape(key.replace('_', ' ').title())}</option>"
        for key in clothing_categories
    )
    return f"""<!doctype html><meta charset='utf-8'><title>Character Foundry</title>
<style>*{{box-sizing:border-box}}body{{font:15px Segoe UI,system-ui;background:#0e1118;color:#eef;margin:0}}header{{padding:20px 28px;background:#171c27}}main{{padding:22px;display:grid;grid-template-columns:minmax(310px,.75fr) minmax(440px,1.25fr);gap:20px}}section{{background:#181e2a;border:1px solid #30394d;border-radius:13px;padding:16px;margin-bottom:15px}}h1,h2{{margin-top:0}}label{{display:block;margin:7px 0}}input,select,textarea,button{{font:inherit}}input[type=number],select,textarea{{width:100%;padding:8px;background:#101621;color:#fff;border:1px solid #46516a;border-radius:5px}}textarea{{min-height:58px}}.prompt{{min-height:220px}}button{{padding:9px 13px;border:0;border-radius:6px;background:#3978aa;color:#fff;cursor:pointer;margin:4px}}button.secondary{{background:#50586c}}button.tiny{{padding:4px 7px;font-size:12px}}.slider,.attr{{padding:10px;border-top:1px solid #30394d}}.slider span,.slider small{{display:block;color:#b8c2d8;margin:5px 0}}.controls{{display:grid;grid-template-columns:1fr 1fr;gap:8px}}.attr-head{{display:flex;justify-content:space-between;align-items:center}}.attr-head label{{margin:0}}.notice{{color:#b9c5dc}}#message{{padding:9px;color:#9fe0ad;overflow-wrap:anywhere}}.saved{{display:grid;grid-template-columns:1fr auto;gap:6px}}@media(max-width:900px){{main{{grid-template-columns:1fr}}}}</style>
<header><h1>The Character Foundry</h1><div class='notice'>Seeded character invention. Drafts and slider settings are proposals until promoted through Character Factory approval.</div></header>
<main><div><section><h2>Roll controls</h2><div class='controls'><label>Seed<input id='seed' type='number' value='72028'></label><label>Character<select id='gender'><option value='random'>Random</option><option value='female' selected>Female</option><option value='male'>Male</option></select></label><label>Minimum age<input id='ageMin' type='number' value='25' min='18' max='100'></label><label>Maximum age<input id='ageMax' type='number' value='55' min='18' max='100'></label><label>Randomness<select id='randomness'><option>plausible</option><option>eccentric</option><option>imaginative</option></select></label><label>Prompt mode<select id='promptMode' onchange='showPromptMode()'><option value='portrait'>Portrait</option><option value='full_body'>Full Body</option></select></label><label>Full-body clothing<select id='clothing' onchange='refreshPrompts()'>{clothing_options}</select></label></div><button onclick='roll()'>Generate / Reroll unlocked</button><button class='secondary' onclick='refreshPrompts()'>Refresh prompts from edits</button><p class='notice'>Checked attributes are copied exactly from canonical state. Manual edits remain canonical, including while locked.</p></section>
<section><h2>Saved drafts</h2><div class='saved'><select id='savedDrafts'></select><button class='secondary' onclick='loadDraft()'>Load</button></div></section>
<section><h2>Appearance Control Box</h2><p class='notice'>Optional slider selections add LoRA tags to the prompts. The corresponding LoRA must be installed in your generation UI; model files are not included with Foundry.</p>{''.join(sliders)}</section></div>
<div><section><h2>Canonical character attributes</h2><div id='attrs'>{attribute_rows}</div></section><section><h2>Generated prompts</h2><h3>Portrait</h3><textarea class='prompt' id='portraitPrompt'></textarea><button onclick='copyField("portraitPrompt")'>Copy portrait prompt</button><h3>Full Body</h3><textarea class='prompt' id='fullBodyPrompt'></textarea><button onclick='copyField("fullBodyPrompt")'>Copy full-body prompt</button><h3>Active mode</h3><textarea class='prompt' id='activePrompt'></textarea><button onclick='copyField("activePrompt")'>Copy active prompt</button><h3>Negative prompt</h3><textarea id='negative'></textarea><button onclick='copyField("negative")'>Copy negative prompt</button><button class='secondary' onclick='saveDraft()'>Save DNA draft</button><button class='secondary' onclick='exportWildcards()'>Export wildcards</button><div id='message'></div></section></div></main>
<script>let current=null;let requestSequence=0;let appliedSequence=0;
function selections(){{return [...document.querySelectorAll('.slider')].filter(x=>x.querySelector('.slider-on').checked).map(x=>({{slider_id:x.dataset.id,enabled:true,weight:Number(x.querySelector('.slider-weight').value)}}))}}
function lockedKeys(){{return [...document.querySelectorAll('.lock')].filter(x=>x.checked).map(x=>x.dataset.key)}}
function canonicalAttributes(){{let out={{}};document.querySelectorAll('[id^="attr-"]').forEach(x=>{{if(x.value.trim())out[x.dataset.key]=x.value.trim()}});return out}}
function editAttribute(el){{if(current)current.attributes[el.dataset.key]=el.value.trim()}}
function syncDraft(){{if(!current)return;current.attributes=canonicalAttributes();current.lock_state=lockedKeys();current.locks={{}};current.lock_state.forEach(k=>{{if(current.attributes[k])current.locks[k]=current.attributes[k]}});current.prompt_mode=document.getElementById('promptMode').value;current.clothing_category=document.getElementById('clothing').value;current.slider_proposals=selections()}}
async function roll(fields=null){{let seq=++requestSequence;let seed=Number(document.getElementById('seed').value);if(current){{seed++;document.getElementById('seed').value=seed}}let body={{seed:seed,constraints:{{gender:document.getElementById('gender').value,age_min:Number(document.getElementById('ageMin').value),age_max:Number(document.getElementById('ageMax').value),mode:document.getElementById('randomness').value}},canonical_attributes:current?canonicalAttributes():{{}},locked_attributes:lockedKeys(),regenerate_fields:fields,sliders:selections(),prompt_mode:document.getElementById('promptMode').value,clothing_category:document.getElementById('clothing').value}};let r=await fetch('/api/generate',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(body)}});let x=await r.json();if(seq<requestSequence)return;if(!x.ok){{alert(x.error);return}}appliedSequence=seq;applyDraft(x.draft)}}
function rerollOne(key){{roll([key])}}
function applyDraft(draft){{current=draft;document.getElementById('seed').value=current.seed;Object.entries(current.attributes||{{}}).forEach(([k,v])=>{{let e=document.getElementById('attr-'+k);if(e)e.value=v}});let locked=new Set(current.lock_state||Object.keys(current.locks||{{}}));document.querySelectorAll('.lock').forEach(x=>x.checked=locked.has(x.dataset.key));document.getElementById('promptMode').value=current.prompt_mode||'portrait';document.getElementById('clothing').value=current.clothing_category||'simple_neutral';document.querySelectorAll('.slider').forEach(x=>{{let item=(current.slider_proposals||[]).find(s=>s.slider_id===x.dataset.id);x.querySelector('.slider-on').checked=!!item;if(item)x.querySelector('.slider-weight').value=item.weight}});document.getElementById('portraitPrompt').value=current.portrait_prompt||'';document.getElementById('fullBodyPrompt').value=current.full_body_prompt||'';document.getElementById('negative').value=current.negative_prompt||'';showPromptMode();document.getElementById('message').textContent='Draft '+current.draft_id+' · '+current.seed}}
function showPromptMode(){{let mode=document.getElementById('promptMode').value;document.getElementById('activePrompt').value=mode==='full_body'?document.getElementById('fullBodyPrompt').value:document.getElementById('portraitPrompt').value;if(current){{current.prompt_mode=mode;current.active_prompt=document.getElementById('activePrompt').value}}}}
async function refreshPrompts(){{if(!current)return;syncDraft();let r=await fetch('/api/compose',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{attributes:current.attributes,sliders:current.slider_proposals,clothing_category:current.clothing_category}})}});let x=await r.json();if(!x.ok){{alert(x.error);return}}current.slider_proposals=x.sliders;current.portrait_prompt=x.prompts.portrait_prompt;current.full_body_prompt=x.prompts.full_body_prompt;document.getElementById('portraitPrompt').value=current.portrait_prompt;document.getElementById('fullBodyPrompt').value=current.full_body_prompt;showPromptMode()}}
async function copyField(id){{await navigator.clipboard.writeText(document.getElementById(id).value);document.getElementById('message').textContent='Prompt copied.'}}
async function saveDraft(){{if(!current)return alert('Generate a draft first.');syncDraft();await refreshPrompts();current.negative_prompt=document.getElementById('negative').value;let r=await fetch('/api/save',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{draft:current}})}});let x=await r.json();document.getElementById('message').textContent=x.ok?'Saved '+x.path:x.error;if(x.ok)loadDraftList()}}
async function loadDraftList(){{let r=await fetch('/api/drafts');let x=await r.json();let e=document.getElementById('savedDrafts');e.innerHTML=(x.drafts||[]).map(n=>'<option>'+n.replaceAll('&','&amp;').replaceAll('<','&lt;')+'</option>').join('')}}
async function loadDraft(){{let name=document.getElementById('savedDrafts').value;if(!name)return;let r=await fetch('/api/load',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{name:name}})}});let x=await r.json();if(!x.ok){{alert(x.error);return}}applyDraft(x.draft);if(!current.full_body_prompt)await refreshPrompts()}}
async function exportWildcards(){{if(!current)return alert('Generate a draft first.');syncDraft();await refreshPrompts();let r=await fetch('/api/export-wildcards',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{draft:current}})}});let x=await r.json();document.getElementById('message').textContent=x.ok?'Wildcard package: '+x.path:x.error}}
loadDraftList();roll();</script>"""
