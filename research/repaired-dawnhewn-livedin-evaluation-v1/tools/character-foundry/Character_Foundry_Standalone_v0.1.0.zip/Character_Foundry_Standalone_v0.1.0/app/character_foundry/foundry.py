from __future__ import annotations

import hashlib
import math
import random
from copy import deepcopy
from pathlib import Path
from typing import Any

from .dna import DNA_SCHEMA, attribute, finalize_dna
from .io import stable_digest
from .registry import validate_registry

GENERATOR_VERSION = "character-factory.foundry-generator.v0.2"
DRAFT_SCHEMA = "character-factory.foundry-draft.v0.2"
SUPPORTED_DRAFT_SCHEMAS = {"character-factory.foundry-draft.v0.1", DRAFT_SCHEMA}

ATTRIBUTE_KEYS = (
    "gender", "age", "face_shape", "eyes", "eye_color", "nose", "mouth", "skin",
    "hair_color", "hair_style", "body_build", "distinctive_feature", "expression", "wardrobe",
)

CLOTHING_CATEGORIES = {
    "casual_fitted": (
        "casual clothing that conforms naturally to the established anatomy, with realistic fabric tension, "
        "folds, and drape"
    ),
    "athletic": (
        "simple athletic clothing that follows the established body proportions without reshaping them"
    ),
    "swimwear": (
        "plain practical swimwear that leaves the overall body silhouette clearly readable"
    ),
    "simple_neutral": (
        "simple neutral clothing that follows the contours of the established physique without changing its volume"
    ),
}


OPTIONS: dict[str, list[str]] = {
    "face_shape": [
        "long oval face", "broad square face", "soft heart-shaped face",
        "narrow angular face", "round face with a strong jaw", "diamond-shaped face",
    ],
    "eyes": [
        "small deep-set eyes", "large wide-set eyes", "hooded almond-shaped eyes",
        "slightly asymmetrical eyes", "narrow expressive eyes", "round alert eyes",
    ],
    "eye_color": ["green", "hazel", "dark brown", "gray-blue", "amber", "blue-green"],
    "nose": [
        "broad expressive nose", "long aquiline nose", "short upturned nose",
        "crooked prominent nose", "wide softly rounded nose", "narrow straight nose",
    ],
    "mouth": [
        "wide expressive mouth", "small sharply defined mouth", "full asymmetrical lips",
        "thin mobile lips", "softly bowed lips", "slightly crooked smile",
    ],
    "skin": [
        "fair freckled skin with natural tonal variation and fine visible texture",
        "warm brown skin with natural tonal variation and fine visible texture",
        "deep brown skin with natural tonal variation and a restrained satin finish",
        "olive skin with subtle uneven pigmentation, visible pores, and fine vellus hair",
        "golden tan skin with natural tonal variation and restrained highlights",
        "pale skin with a few visible moles, fine pores, and subtle color variation",
    ],
    "hair_color": ["dark brown", "black", "copper-red", "ash blonde", "silver-gray", "chestnut brown"],
    "hair_style": [
        "short tousled hair", "chin-length wavy hair", "long loose curls",
        "straight shoulder-length hair", "close-cropped hair", "thick hair in a loose braid",
    ],
    "body_build": [
        "lean wiry physique with long slender limbs", "compact stocky physique with sturdy limbs",
        "soft full hourglass figure", "tall broad-shouldered athletic build",
        "short slight build with narrow shoulders", "substantial pear-shaped figure",
    ],
    "distinctive_feature": [
        "subtly asymmetric features", "large slightly protruding ears",
        "a narrow healed vertical scar visibly interrupting the hair of the left eyebrow",
        "a distinctive small birthmark at the right temple", "high angular cheekbones", "a strong cleft chin",
        "one eyebrow set slightly higher than the other", "a small gap between the front teeth",
        "a cluster of three small moles on one cheek", "a slightly crooked nose from an old break",
        "a pronounced cupid's bow", "a faint dimple in one cheek",
    ],
    "expression": [
        "thoughtful guarded expression", "calm self-possessed expression", "wry restrained smile",
        "curious alert expression", "gentle serious expression", "confident unsmiling expression",
    ],
    "wardrobe": [
        "understated everyday clothing", "a weathered denim jacket over a plain shirt",
        "a practical linen shirt", "a simple dark crew-neck shirt", "an eccentric tailored jacket",
        "comfortable workwear",
    ],
}


def generate_draft(
    seed: int,
    registry: dict[str, Any],
    *,
    constraints: dict[str, Any] | None = None,
    locks: dict[str, str] | None = None,
    slider_selections: list[dict[str, Any]] | None = None,
    canonical_attributes: dict[str, Any] | None = None,
    locked_attributes: list[str] | set[str] | tuple[str, ...] | None = None,
    regenerate_fields: list[str] | set[str] | tuple[str, ...] | None = None,
    prompt_mode: str = "portrait",
    clothing_category: str = "simple_neutral",
    descriptor_catalog: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a deterministic, unapproved character concept and Forge-ready prompt."""
    validate_registry(registry)
    descriptor_options = OPTIONS if descriptor_catalog is None else descriptor_catalog["attributes"]
    clothing_categories = CLOTHING_CATEGORIES if descriptor_catalog is None else descriptor_catalog["clothing_categories"]
    constraints = deepcopy(constraints or {})
    # ``locks`` is the v0.1 API.  It remains accepted, while v0.2 keeps the
    # canonical values and independent lock state explicit.
    legacy_locks = {str(key): str(value) for key, value in (locks or {}).items() if str(value).strip()}
    canonical = {
        str(key): str(value) for key, value in (canonical_attributes or {}).items()
        if str(key) in ATTRIBUTE_KEYS and str(value).strip()
    }
    canonical.update(legacy_locks)
    locked = {str(key) for key in (locked_attributes or legacy_locks.keys())}
    unknown_locks = locked.difference(ATTRIBUTE_KEYS)
    if unknown_locks:
        raise ValueError(f"Unknown Foundry locked attributes: {sorted(unknown_locks)}")
    regenerate = None if regenerate_fields is None else {str(key) for key in regenerate_fields}
    if regenerate is not None:
        unknown_regenerate = regenerate.difference(ATTRIBUTE_KEYS)
        if unknown_regenerate:
            raise ValueError(f"Unknown Foundry regeneration attributes: {sorted(unknown_regenerate)}")
    if prompt_mode not in {"portrait", "full_body"}:
        raise ValueError("Foundry prompt mode must be portrait or full_body")
    if clothing_category not in clothing_categories:
        raise ValueError(f"Unknown Foundry clothing category: {clothing_category}")
    mode = str(constraints.get("mode", "plausible"))
    if mode not in {"plausible", "eccentric", "imaginative"}:
        raise ValueError("Foundry mode must be plausible, eccentric, or imaginative")
    gender = str(constraints.get("gender", "random"))
    if gender not in {"female", "male", "random"}:
        raise ValueError("Foundry gender must be female, male, or random")
    age_min = int(constraints.get("age_min", 25))
    age_max = int(constraints.get("age_max", 55))
    if age_min < 18 or age_max < age_min or age_max > 100:
        raise ValueError("Foundry age range must be ordered and explicitly adult (18..100)")

    def retain(key: str) -> bool:
        return key in canonical and (key in locked or (regenerate is not None and key not in regenerate))

    resolved_gender = canonical["gender"] if retain("gender") else (
        _choice(seed, "gender", ["female", "male"]) if gender == "random" else gender
    )
    age = int(canonical["age"]) if retain("age") else _integer(seed, "age", age_min, age_max)
    values = {
        key: canonical[key] if retain(key) else _choice(seed, key, options)
        for key, options in descriptor_options.items()
    }
    if mode == "plausible":
        # One distinctive feature is enough for a memorable but usable baseline.
        if not retain("distinctive_feature"):
            values["distinctive_feature"] = _choice(
                seed, "distinctive_feature-plausible",
                descriptor_options["distinctive_feature"][:3] + descriptor_options["distinctive_feature"][4:],
            )
    elif mode == "imaginative" and not retain("distinctive_feature"):
        values["distinctive_feature"] = _choice(seed, "distinctive-feature-imaginative", descriptor_options["distinctive_feature"])

    attributes = {"gender": resolved_gender, "age": str(age), **values}
    sliders = resolve_foundry_sliders(registry, slider_selections or [])
    compiled = compose_foundry_prompts(
        attributes, sliders, clothing_category=clothing_category, clothing_categories=clothing_categories
    )
    description = compiled["description"]
    portrait_prompt = compiled["portrait_prompt"]
    full_body_prompt = compiled["full_body_prompt"]
    negative_prompt = ", ".join([
        "beauty retouching", "airbrushed skin", "plastic skin", "waxy skin", "wet skin", "oily skin",
        "harsh ring light", "blown skin highlights", "excessive sharpening", "heavy makeup",
        "text", "watermark",
    ])
    character_id = f"foundry-{seed}"
    dna = finalize_dna({
        "schema_version": DNA_SCHEMA,
        "dna_revision": 1,
        "character_id": character_id,
        "identity_invariants": {
            "adult_age": attribute(str(age), "generated_intent"),
            "class_noun": attribute(compiled["class_noun"], "generated_intent"),
            "facial_geometry": attribute(", ".join([values["face_shape"], values["eyes"], values["nose"], values["mouth"], values["distinctive_feature"]]), "generated_intent"),
            "eyes": attribute(f"{values['eyes']} with {values['eye_color']} irises", "generated_intent"),
            "skin": attribute(values["skin"], "generated_intent"),
            "natural_hair": attribute(f"{values['hair_style']}, {values['hair_color']} hair", "generated_intent"),
            "body_build": attribute(values["body_build"], "generated_intent"),
            "trigger": attribute("", "generated_intent"),
            "permanent_traits": attribute([
                values["face_shape"], values["eyes"], values["eye_color"], values["nose"],
                values["mouth"], values["distinctive_feature"], values["skin"],
                values["hair_style"], values["hair_color"], values["body_build"],
            ], "generated_intent"),
        },
        "permitted_variations": {},
        "presentation_defaults": {
            "expression": attribute(values["expression"], "generated_intent"),
            "wardrobe": attribute(values["wardrobe"], "generated_intent"),
            "style": attribute("candid editorial portrait photography", "generated_intent"),
        },
        "appearance_revision_reference": {"revision": 0, "fingerprint": None},
        "reference_anchors": [],
        "failure_modes": [],
    })
    draft = {
        "schema_version": DRAFT_SCHEMA,
        "generator_version": GENERATOR_VERSION,
        "draft_id": f"foundry-{seed}-{stable_digest({'seed': seed, 'constraints': constraints, 'canonical': canonical, 'locked': sorted(locked), 'sliders': sliders})[:10]}",
        "seed": seed,
        "constraints": constraints,
        "locks": {key: attributes[key] for key in sorted(locked) if key in attributes},
        "lock_state": sorted(locked),
        "attributes": attributes,
        "description": description,
        "portrait_prompt": portrait_prompt,
        "full_body_prompt": full_body_prompt,
        "prompt_mode": prompt_mode,
        "active_prompt": portrait_prompt if prompt_mode == "portrait" else full_body_prompt,
        "clothing_category": clothing_category,
        "negative_prompt": negative_prompt,
        "slider_proposals": sliders,
        "descriptor_catalog": ({
            "schema_version": descriptor_catalog.get("schema_version"),
            "catalog_version": descriptor_catalog.get("catalog_version"),
            "fingerprint": descriptor_catalog.get("fingerprint"),
        } if descriptor_catalog else {"schema_version": "built-in", "catalog_version": GENERATOR_VERSION}),
        "character_dna": dna,
        "approval_state": "uncommitted_proposal",
        "notice": "Generated intent only. Human selection and Character Factory approval are required before identity is canonical.",
    }
    draft["fingerprint"] = stable_digest(draft)
    return draft


def compose_foundry_prompts(
    attributes: dict[str, Any],
    sliders: list[dict[str, Any]],
    *,
    clothing_category: str = "simple_neutral",
    clothing_categories: dict[str, str] | None = None,
) -> dict[str, str]:
    """Compile portrait and full-body prompts from one canonical identity state."""
    missing = [key for key in ATTRIBUTE_KEYS if not str(attributes.get(key, "")).strip()]
    if missing:
        raise ValueError(f"Foundry attributes are incomplete: {missing}")
    clothing_categories = CLOTHING_CATEGORIES if clothing_categories is None else clothing_categories
    if clothing_category not in clothing_categories:
        raise ValueError(f"Unknown Foundry clothing category: {clothing_category}")
    gender = str(attributes["gender"])
    noun = "woman" if gender == "female" else "man" if gender == "male" else gender
    class_noun = f"{attributes['age']}-year-old adult {noun}"
    face = ", ".join([
        str(attributes["face_shape"]),
        f"{attributes['eyes']} with {attributes['eye_color']} irises",
        str(attributes["nose"]), str(attributes["mouth"]), str(attributes["distinctive_feature"]),
    ])
    identity = [
        class_noun, face, str(attributes["skin"]),
        f"{attributes['hair_style']}, {attributes['hair_color']} hair",
        str(attributes["body_build"]),
    ]
    description = ", ".join(item for item in identity if item)
    tags = [str(item["prompt_tag"]) for item in sliders]
    suffix = ("\n" + "\n".join(tags)) if tags else ""
    portrait = ", ".join([
        f"a natural unretouched head-and-shoulders editorial photograph of a {description}",
        str(attributes["expression"]), str(attributes["wardrobe"]),
        "eye-level camera with shoulders visible and modest breathing room around the head",
        "soft diffuse window light from one side with gentle shadow modeling",
        "real skin with visible pores, fine vellus hair, subtle uneven pigmentation, and restrained highlights",
        "plain unobtrusive background", "candid documentary portrait photography",
    ]) + suffix
    full_body = ", ".join([
        f"a natural unretouched full-length editorial photograph of a {class_noun}",
        str(attributes["body_build"]),
        "the complete person visible from the top of the hair through both complete feet and footwear",
        "natural human anatomy and proportions, a clear readable body silhouette",
        f"shoulders, torso, waist, hips, and limbs consistent with the established physique",
        face,
        str(attributes["skin"]),
        f"{attributes['hair_style']}, {attributes['hair_color']} hair with a clearly readable silhouette",
        clothing_categories[clothing_category],
        str(attributes["expression"]),
        "plain minimally distracting environment, soft even neutral photographic lighting",
        "realistic documentary photography, no unnecessary props",
    ]) + suffix
    return {
        "class_noun": class_noun,
        "description": description,
        "portrait_prompt": portrait,
        "full_body_prompt": full_body,
    }


def build_wildcard_export(
    draft: dict[str, Any],
    *,
    descriptor_catalog: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a non-destructive wildcard package; the structured draft stays authoritative."""
    attributes = {str(key): str(value) for key, value in draft["attributes"].items()}
    locked = set(draft.get("lock_state") or draft.get("locks", {}).keys())
    wildcard_attributes = dict(attributes)
    categories: dict[str, list[str]] = {}
    constraints = draft.get("constraints", {})
    descriptor_options = OPTIONS if descriptor_catalog is None else descriptor_catalog["attributes"]
    clothing_categories = CLOTHING_CATEGORIES if descriptor_catalog is None else descriptor_catalog["clothing_categories"]
    for key in ATTRIBUTE_KEYS:
        if key in locked:
            continue
        wildcard_attributes[key] = f"__foundry_{key}__"
        if key == "gender":
            constrained_gender = str(constraints.get("gender", "random"))
            categories[key] = [constrained_gender] if constrained_gender in {"female", "male"} else ["female", "male"]
        elif key == "age":
            low = int(constraints.get("age_min", attributes[key]))
            high = int(constraints.get("age_max", attributes[key]))
            categories[key] = [str(value) for value in range(low, high + 1)]
        else:
            categories[key] = list(descriptor_options[key])
    clothing_key = str(draft.get("clothing_category", "simple_neutral"))
    compiled = compose_foundry_prompts(
        wildcard_attributes,
        draft.get("slider_proposals", []),
        clothing_category=clothing_key,
        clothing_categories=clothing_categories,
    )
    return {
        "schema_version": "character-factory.foundry-wildcard-export.v0.1",
        "source_draft_id": draft["draft_id"],
        "source_fingerprint": draft.get("fingerprint"),
        "generator_version": draft.get("generator_version"),
        "seed": draft.get("seed"),
        "locked_attributes": sorted(locked),
        "categories": categories,
        "portrait_template": compiled["portrait_prompt"],
        "full_body_template": compiled["full_body_prompt"],
        "slider_proposals": deepcopy(draft.get("slider_proposals", [])),
        "notice": "Wildcards are an export view. The structured Foundry draft remains the source of truth.",
    }


def resolve_foundry_sliders(registry: dict[str, Any], selections: list[dict[str, Any]]) -> list[dict[str, Any]]:
    validate_registry(registry)
    definitions = {entry["slider_id"]: entry for entry in registry.get("sliders", [])}
    resolved = []
    seen: set[str] = set()
    for order, choice in enumerate(selections):
        if not choice.get("enabled", True):
            continue
        slider_id = str(choice.get("slider_id", ""))
        if slider_id in seen:
            raise ValueError(f"Duplicate Foundry slider: {slider_id}")
        seen.add(slider_id)
        if slider_id not in definitions:
            raise ValueError(f"Unknown Foundry slider: {slider_id}")
        definition = definitions[slider_id]
        if not definition.get("selectable"):
            raise ValueError(f"Slider is not validated/selectable: {slider_id}")
        weight = float(choice.get("weight", definition["default_weight"]))
        low, high = definition["validated_range"]
        step = float(definition["step_size"])
        if not low <= weight <= high:
            raise ValueError(f"Weight {weight} is outside {low}..{high} for {slider_id}")
        if not math.isclose((weight - low) / step, round((weight - low) / step), abs_tol=1e-8):
            raise ValueError(f"Weight {weight} is not aligned to step {step} for {slider_id}")
        prompt_name = str(definition.get("prompt_name") or Path(definition["file_path"]).stem)
        resolved.append({
            "stack_order": order,
            "slider_id": slider_id,
            "display_name": definition["display_name"],
            "prompt_name": prompt_name,
            "weight": weight,
            "role": definition["role"],
            "sha256": definition["sha256"],
            "prompt_tag": f"<lora:{prompt_name}:{_format_weight(weight)}>",
        })
    return resolved


def _rng(seed: int, field: str) -> random.Random:
    digest = hashlib.sha256(f"{GENERATOR_VERSION}|{seed}|{field}".encode("utf-8")).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def _choice(seed: int, field: str, values: list[str]) -> str:
    return values[_rng(seed, field).randrange(len(values))]


def _integer(seed: int, field: str, low: int, high: int) -> int:
    return _rng(seed, field).randint(low, high)


def _format_weight(value: float) -> str:
    text = f"{value:.4f}".rstrip("0").rstrip(".")
    return "0" if text in {"-0", ""} else text
